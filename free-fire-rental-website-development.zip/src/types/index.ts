import type { users, ffAccounts, rentalOrders, notifications, pricing } from "@/db/schema";

// ==================== USER TYPES ====================

export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;

export type UserProfile = Pick<
  User,
  | "id"
  | "email"
  | "username"
  | "fullName"
  | "phone"
  | "avatar"
  | "role"
  | "emailVerified"
  | "emailVerifiedAt"
  | "isActive"
  | "createdAt"
>;

export type UserSafe = Omit<User, "password">;

// ==================== ACCOUNT TYPES ====================

export type FFAccount = typeof ffAccounts.$inferSelect;
export type NewFFAccount = typeof ffAccounts.$inferInsert;

export type AccountWithPricing = FFAccount & {
  pricing: Pricing[];
};

export type AccountCardData = Pick<
  FFAccount,
  "id" | "name" | "description" | "imageUrl" | "status" | "level" | "rank" | "currentExpiresAt"
> & {
  pricing: Pick<Pricing, "hours" | "price">[];
};

// ==================== PRICING TYPES ====================

export type Pricing = typeof pricing.$inferSelect;
export type NewPricing = typeof pricing.$inferInsert;

// ==================== ORDER TYPES ====================

export type RentalOrder = typeof rentalOrders.$inferSelect;
export type NewRentalOrder = typeof rentalOrders.$inferInsert;

export type OrderWithDetails = RentalOrder & {
  account: Pick<FFAccount, "id" | "name" | "imageUrl" | "status">;
  user: Pick<User, "id" | "username" | "fullName" | "email">;
};

// ==================== NOTIFICATION TYPES ====================

export type Notification = typeof notifications.$inferSelect;

// ==================== API TYPES ====================

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

// ==================== AUTH TYPES ====================

export interface AuthState {
  user: UserSafe | null;
  token: string | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  setUser: (user: UserSafe | null) => void;
  setToken: (token: string | null) => void;
  logout: () => void;
}

// ==================== THEME TYPES ====================

export type Theme = "dark" | "light";
