import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { UserSafe, Theme } from "@/types";

interface AuthState {
  user: UserSafe | null;
  token: string | null;
  isLoading: boolean;
  theme: Theme;
  setUser: (user: UserSafe | null) => void;
  setToken: (token: string | null) => void;
  setLoading: (loading: boolean) => void;
  setTheme: (theme: Theme) => void;
  logout: () => void;
  hydrate: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      isLoading: true,
      theme: "dark" as Theme,
      setUser: (user) => set({ user }),
      setToken: (token) => set({ token }),
      setLoading: (isLoading) => set({ isLoading }),
      setTheme: (theme) => {
        set({ theme });
        if (typeof document !== "undefined") {
          document.documentElement.classList.toggle("dark", theme === "dark");
          document.documentElement.classList.toggle("light", theme === "light");
        }
      },
      logout: () => {
        set({ user: null, token: null });
        if (typeof document !== "undefined") {
          document.cookie = "auth_token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT";
        }
      },
      hydrate: () => set({ isLoading: false }),
    }),
    {
      name: "ff-rent-auth",
      partialize: (state) => ({
        user: state.user,
        token: state.token,
        theme: state.theme,
      }),
    }
  )
);

// ==================== NOTIFICATION STORE ====================

interface NotificationState {
  unreadCount: number;
  setUnreadCount: (count: number) => void;
  decrementUnread: () => void;
  resetUnread: () => void;
}

export const useNotificationStore = create<NotificationState>()((set) => ({
  unreadCount: 0,
  setUnreadCount: (unreadCount) => set({ unreadCount }),
  decrementUnread: () => set((state) => ({ unreadCount: Math.max(0, state.unreadCount - 1) })),
  resetUnread: () => set({ unreadCount: 0 }),
}));
