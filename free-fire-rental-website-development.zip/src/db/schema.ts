import {
  pgTable,
  uuid,
  varchar,
  text,
  boolean,
  integer,
  timestamp,
  bigint,
  pgEnum,
  decimal,
} from "drizzle-orm/pg-core";

// ==================== ENUMS ====================

export const userRoleEnum = pgEnum("user_role", ["user", "admin"]);
export const accountStatusEnum = pgEnum("account_status", [
  "available",
  "pending_payment",
  "rented",
  "maintenance",
  "locked",
]);
export const orderStatusEnum = pgEnum("order_status", [
  "pending_payment",
  "awaiting_confirmation",
  "active",
  "completed",
  "expired",
  "cancelled",
]);
export const paymentStatusEnum = pgEnum("payment_status", [
  "pending",
  "confirmed",
  "rejected",
  "refunded",
]);
export const notificationTypeEnum = pgEnum("notification_type", [
  "system",
  "order",
  "payment",
  "account",
  "security",
  "promo",
]);

// ==================== USERS ====================

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  password: text("password").notNull(),
  fullName: varchar("full_name", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  avatar: text("avatar"),
  role: userRoleEnum("role").default("user").notNull(),
  emailVerified: boolean("email_verified").default(false).notNull(),
  emailVerifiedAt: timestamp("email_verified_at", { withTimezone: true }),
  isActive: boolean("is_active").default(true).notNull(),
  failedLoginAttempts: integer("failed_login_attempts").default(0).notNull(),
  lockedUntil: timestamp("locked_until", { withTimezone: true }),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  lastLoginIp: varchar("last_login_ip", { length: 45 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// ==================== EMAIL VERIFICATIONS ====================

export const emailVerifications = pgTable("email_verifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .references(() => users.id, { onDelete: "cascade" })
    .notNull(),
  token: varchar("token", { length: 255 }).notNull().unique(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  used: boolean("used").default(false).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ==================== PASSWORD RESETS ====================

export const passwordResets = pgTable("password_resets", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .references(() => users.id, { onDelete: "cascade" })
    .notNull(),
  token: varchar("token", { length: 255 }).notNull().unique(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  used: boolean("used").default(false).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ==================== SESSIONS ====================

export const sessions = pgTable("sessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .references(() => users.id, { onDelete: "cascade" })
    .notNull(),
  token: varchar("token", { length: 500 }).notNull().unique(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  ip: varchar("ip", { length: 45 }),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ==================== FREE FIRE ACCOUNTS ====================

export const ffAccounts = pgTable("ff_accounts", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  imageUrl: text("image_url"),
  status: accountStatusEnum("status").default("available").notNull(),
  gameEmail: varchar("game_email", { length: 255 }),
  gamePassword: varchar("game_password", { length: 255 }),
  level: varchar("level", { length: 50 }),
  rank: varchar("rank", { length: 100 }),
  skins: text("skins"),
  diamonds: integer("diamonds").default(0),
  currentRenterId: uuid("current_renter_id").references(() => users.id),
  currentOrderId: uuid("current_order_id"),
  currentExpiresAt: timestamp("current_expires_at", { withTimezone: true }),
  sortOrder: integer("sort_order").default(0).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// ==================== PRICING ====================

export const pricing = pgTable("pricing", {
  id: uuid("id").primaryKey().defaultRandom(),
  accountId: uuid("account_id")
    .references(() => ffAccounts.id, { onDelete: "cascade" })
    .notNull(),
  hours: integer("hours").notNull(),
  price: integer("price").notNull(), // stored in VND (no decimals)
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// ==================== RENTAL ORDERS ====================

export const rentalOrders = pgTable("rental_orders", {
  id: uuid("id").primaryKey().defaultRandom(),
  orderCode: varchar("order_code", { length: 50 }).notNull().unique(),
  receiveCode: varchar("receive_code", { length: 50 }).notNull().unique(),
  userId: uuid("user_id")
    .references(() => users.id, { onDelete: "cascade" })
    .notNull(),
  accountId: uuid("account_id")
    .references(() => ffAccounts.id, { onDelete: "cascade" })
    .notNull(),
  hours: integer("hours").notNull(),
  price: integer("price").notNull(), // total price in VND
  status: orderStatusEnum("status").default("pending_payment").notNull(),
  paymentStatus: paymentStatusEnum("payment_status").default("pending").notNull(),
  paymentMethod: varchar("payment_method", { length: 100 }).default("bank_transfer"),
  paymentContent: varchar("payment_content", { length: 255 }),
  paymentConfirmedAt: timestamp("payment_confirmed_at", { withTimezone: true }),
  paymentConfirmedBy: uuid("payment_confirmed_by").references(() => users.id),
  startedAt: timestamp("started_at", { withTimezone: true }),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
  cancelReason: text("cancel_reason"),
  isExtension: boolean("is_extension").default(false).notNull(),
  parentOrderId: uuid("parent_order_id"),
  holdExpiresAt: timestamp("hold_expires_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// ==================== NOTIFICATIONS ====================

export const notifications = pgTable("notifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .references(() => users.id, { onDelete: "cascade" })
    .notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  type: notificationTypeEnum("type").default("system").notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  relatedId: uuid("related_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ==================== AUDIT LOGS ====================

export const auditLogs = pgTable("audit_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").references(() => users.id),
  action: varchar("action", { length: 100 }).notNull(),
  entity: varchar("entity", { length: 100 }),
  entityId: uuid("entity_id"),
  details: text("details"),
  ip: varchar("ip", { length: 45 }),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ==================== LOGIN ATTEMPTS ====================

export const loginAttempts = pgTable("login_attempts", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: varchar("email", { length: 255 }),
  ip: varchar("ip", { length: 45 }),
  success: boolean("success").default(false).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ==================== SITE CONFIG ====================

export const siteConfig = pgTable("site_config", {
  id: uuid("id").primaryKey().defaultRandom(),
  key: varchar("key", { length: 255 }).notNull().unique(),
  value: text("value"),
  description: text("description"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// ==================== RELATIONS ====================

import { relations } from "drizzle-orm";

export const usersRelations = relations(users, ({ many }) => ({
  sessions: many(sessions),
  rentalOrders: many(rentalOrders),
  notifications: many(notifications),
  auditLogs: many(auditLogs),
  emailVerifications: many(emailVerifications),
  passwordResets: many(passwordResets),
}));

export const ffAccountsRelations = relations(ffAccounts, ({ many }) => ({
  pricing: many(pricing),
  rentalOrders: many(rentalOrders),
}));

export const pricingRelations = relations(pricing, ({ one }) => ({
  account: one(ffAccounts, {
    fields: [pricing.accountId],
    references: [ffAccounts.id],
  }),
}));

export const rentalOrdersRelations = relations(rentalOrders, ({ one }) => ({
  user: one(users, {
    fields: [rentalOrders.userId],
    references: [users.id],
  }),
  account: one(ffAccounts, {
    fields: [rentalOrders.accountId],
    references: [ffAccounts.id],
  }),
  confirmedBy: one(users, {
    fields: [rentalOrders.paymentConfirmedBy],
    references: [users.id],
    relationName: "confirmedBy",
  }),
}));

export const sessionsRelations = relations(sessions, ({ one }) => ({
  user: one(users, {
    fields: [sessions.userId],
    references: [users.id],
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
}));

export const emailVerificationsRelations = relations(emailVerifications, ({ one }) => ({
  user: one(users, {
    fields: [emailVerifications.userId],
    references: [users.id],
  }),
}));

export const passwordResetsRelations = relations(passwordResets, ({ one }) => ({
  user: one(users, {
    fields: [passwordResets.userId],
    references: [users.id],
  }),
}));

export const auditLogsRelations = relations(auditLogs, ({ one }) => ({
  user: one(users, {
    fields: [auditLogs.userId],
    references: [users.id],
  }),
}));
