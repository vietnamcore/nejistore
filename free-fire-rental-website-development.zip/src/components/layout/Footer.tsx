"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Gamepad2, Mail, Phone, MessageCircle } from "lucide-react";
import { SUPPORT_PHONE, SUPPORT_EMAIL, SUPPORT_ZALO } from "@/lib/constants";

const footerLinks = {
  quickLinks: [
    { href: "/accounts", label: "Tài khoản" },
    { href: "/pricing", label: "Bảng giá" },
    { href: "/orders", label: "Tra cứu đơn" },
    { href: "/contact", label: "Liên hệ" },
  ],
  legal: [
    { href: "/terms", label: "Điều khoản sử dụng" },
    { href: "/privacy", label: "Chính sách bảo mật" },
  ],
};

export default function Footer() {
  return (
    <footer className="relative border-t border-white/5 bg-black/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <Link href="/" className="flex items-center gap-2 mb-4">
              <Gamepad2 className="w-7 h-7 text-primary" />
              <span className="text-lg font-bold bg-gradient-to-r from-primary to-primary-light bg-clip-text text-transparent">
                FF Rent
              </span>
            </Link>
            <p className="text-sm text-neutral-500 leading-relaxed">
              Dịch vụ cho thuê tài khoản Free Fire theo giờ uy tín, nhanh chóng và an toàn.
            </p>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            <h3 className="text-sm font-semibold text-white mb-4">Liên kết nhanh</h3>
            <ul className="space-y-2">
              {footerLinks.quickLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-neutral-500 hover:text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Legal */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            <h3 className="text-sm font-semibold text-white mb-4">Pháp lý</h3>
            <ul className="space-y-2">
              {footerLinks.legal.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-neutral-500 hover:text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Contact */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
          >
            <h3 className="text-sm font-semibold text-white mb-4">Liên hệ</h3>
            <ul className="space-y-3">
              <li>
                <a
                  href={`tel:${SUPPORT_PHONE}`}
                  className="flex items-center gap-2 text-sm text-neutral-500 hover:text-primary transition-colors"
                >
                  <Phone className="w-4 h-4" />
                  {SUPPORT_PHONE}
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${SUPPORT_EMAIL}`}
                  className="flex items-center gap-2 text-sm text-neutral-500 hover:text-primary transition-colors"
                >
                  <Mail className="w-4 h-4" />
                  {SUPPORT_EMAIL}
                </a>
              </li>
              <li>
                <a
                  href={SUPPORT_ZALO}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm text-neutral-500 hover:text-primary transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  Zalo hỗ trợ
                </a>
              </li>
            </ul>
          </motion.div>
        </div>

        {/* Bottom */}
        <div className="mt-12 pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-neutral-600">
            © {new Date().getFullYear()} FF Rent. Tất cả quyền được bảo lưu.
          </p>
          <div className="flex items-center gap-4">
            <span className="text-xs text-neutral-600">
              Made with 💚 for Gamers
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
