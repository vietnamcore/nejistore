"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Clock, Search, Filter, Package } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { useAuthStore } from "@/stores/auth-store";
import { formatCurrency, formatDate, getStatusLabel, getStatusColor } from "@/lib/utils";

export default function HistoryPage() {
  const { token } = useAuthStore();
  const [orders, setOrders] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (token) fetchOrders();
  }, [token, filter]);

  const fetchOrders = async () => {
    setIsLoading(true);
    try {
      const statusParam = filter !== "all" ? `?status=${filter}` : "";
      const res = await fetch(`/api/orders${statusParam}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.success) setOrders(data.data);
    } catch (error) {
      console.error("Fetch orders error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredOrders = orders.filter(
    (o) =>
      o.orderCode.toLowerCase().includes(search.toLowerCase()) ||
      (o.accountName && o.accountName.toLowerCase().includes(search.toLowerCase()))
  );

  const filters = [
    { value: "all", label: "Tất cả" },
    { value: "active", label: "Đang thuê" },
    { value: "completed", label: "Hoàn thành" },
    { value: "expired", label: "Hết hạn" },
    { value: "cancelled", label: "Đã hủy" },
  ];

  return (
    <main className="aurora-bg min-h-screen">
      <Header />
      <div className="max-w-4xl mx-auto px-4 sm:px-6 pt-28 pb-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">
            Lịch Sử <span className="text-primary">Thuê</span>
          </h1>
          <p className="text-neutral-400 mb-8">Xem toàn bộ lịch sử thuê tài khoản</p>

          {/* Search & Filter */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Tìm theo mã đơn hoặc tên tài khoản..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white placeholder-neutral-600 focus:border-primary/50 outline-none text-sm"
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-neutral-500" />
              <div className="flex gap-1">
                {filters.map((f) => (
                  <button
                    key={f.value}
                    onClick={() => setFilter(f.value)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                      filter === f.value
                        ? "bg-primary/10 text-primary"
                        : "text-neutral-500 hover:text-white hover:bg-white/5"
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Orders List */}
          {isLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="skeleton h-20 rounded-xl" />
              ))}
            </div>
          ) : filteredOrders.length === 0 ? (
            <div className="glass rounded-xl p-12 text-center">
              <Package className="w-12 h-12 text-neutral-700 mx-auto mb-3" />
              <p className="text-neutral-500">Không có đơn hàng nào</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredOrders.map((order, i) => (
                <motion.div
                  key={order.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.03 }}
                  className="glass rounded-xl p-4"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-2.5 h-2.5 rounded-full ${
                        order.status === "active" ? "bg-green-400" :
                        order.status === "pending_payment" || order.status === "awaiting_confirmation" ? "bg-yellow-400" :
                        order.status === "completed" ? "bg-blue-400" : "bg-neutral-500"
                      }`} />
                      <div>
                        <p className="text-sm font-medium text-white">{order.accountName || "Tài khoản"}</p>
                        <p className="text-xs text-neutral-500">
                          {order.orderCode} • {order.hours} giờ • {formatDate(order.createdAt)}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-primary">{formatCurrency(order.price)}</p>
                      <p className={`text-xs ${getStatusColor(order.status)}`}>{getStatusLabel(order.status)}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
      <Footer />
    </main>
  );
}
