"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Users,
  Package,
  Gamepad2,
  CreditCard,
  CheckCircle,
  XCircle,
  Clock,
  Loader2,
  Settings,
} from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { useAuthStore } from "@/stores/auth-store";
import { formatCurrency, formatDate, getStatusLabel, getStatusColor } from "@/lib/utils";

interface DashboardData {
  totalUsers: number;
  orderStats: {
    total: number;
    pending: number;
    awaiting: number;
    active: number;
    completed: number;
    totalRevenue: number;
  };
  accountStats: {
    total: number;
    available: number;
    rented: number;
    maintenance: number;
  };
  recentOrders: Array<{
    id: string;
    orderCode: string;
    status: string;
    price: number;
    hours: number;
    createdAt: string;
    accountName: string | null;
    userName: string | null;
  }>;
}

export default function AdminDashboard() {
  const { user, token } = useAuthStore();
  const [data, setData] = useState<DashboardData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [orders, setOrders] = useState<any[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(false);

  useEffect(() => {
    if (token && user?.role === "admin") {
      fetchDashboard();
      fetchPendingOrders();
    }
  }, [token, user]);

  const fetchDashboard = async () => {
    try {
      const res = await fetch("/api/admin/dashboard", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const result = await res.json();
      if (result.success) setData(result.data);
    } catch (error) {
      console.error("Fetch dashboard error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchPendingOrders = async () => {
    setOrdersLoading(true);
    try {
      const res = await fetch("/api/admin/orders?status=awaiting_confirmation", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const result = await res.json();
      if (result.success) setOrders(result.data);
    } catch (error) {
      console.error("Fetch orders error:", error);
    } finally {
      setOrdersLoading(false);
    }
  };

  const handleConfirmOrder = async (orderId: string, action: "confirm" | "reject") => {
    try {
      const res = await fetch("/api/admin/orders", {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ orderId, action }),
      });

      const result = await res.json();
      if (result.success) {
        fetchDashboard();
        fetchPendingOrders();
      }
    } catch (error) {
      console.error("Confirm order error:", error);
    }
  };

  if (!user || user.role !== "admin") {
    return (
      <main className="aurora-bg min-h-screen">
        <Header />
        <div className="flex items-center justify-center min-h-screen">
          <p className="text-neutral-400">Không có quyền truy cập</p>
        </div>
        <Footer />
      </main>
    );
  }

  return (
    <main className="aurora-bg min-h-screen">
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-2xl sm:text-3xl font-bold text-white">
            Admin <span className="text-primary">Dashboard</span>
          </h1>
          <p className="text-neutral-400 mt-1">Quản lý hệ thống cho thuê tài khoản</p>
        </motion.div>

        {/* Admin Nav */}
        <div className="flex flex-wrap gap-3 mb-8">
          {[
            { href: "/admin", label: "Dashboard", icon: Settings },
            { href: "/admin/orders", label: "Đơn hàng", icon: Package },
            { href: "/admin/accounts", label: "Tài khoản", icon: Gamepad2 },
            { href: "/admin/users", label: "Người dùng", icon: Users },
          ].map((link, i) => (
            <Link key={i} href={link.href}>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  i === 0 ? "bg-gradient-to-r from-primary to-primary-dark text-white" : "glass text-neutral-300 hover:text-white"
                }`}
              >
                <link.icon className="w-4 h-4" />
                {link.label}
              </motion.button>
            </Link>
          ))}
        </div>

        {/* Stats */}
        {isLoading ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="skeleton h-24 rounded-xl" />
            ))}
          </div>
        ) : data ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {[
              { icon: Users, label: "Tổng người dùng", value: data.totalUsers, color: "text-blue-400" },
              { icon: Package, label: "Tổng đơn hàng", value: data.orderStats.total, color: "text-yellow-400" },
              { icon: CheckCircle, label: "Đang hoạt động", value: data.orderStats.active, color: "text-green-400" },
              { icon: CreditCard, label: "Doanh thu", value: formatCurrency(data.orderStats.totalRevenue), color: "text-primary" },
              { icon: Clock, label: "Chờ thanh toán", value: data.orderStats.pending, color: "text-yellow-400" },
              { icon: CheckCircle, label: "Chờ xác nhận", value: data.orderStats.awaiting, color: "text-orange-400" },
              { icon: Gamepad2, label: "Acc có sẵn", value: data.accountStats.available, color: "text-green-400" },
              { icon: Gamepad2, label: "Đang thuê", value: data.accountStats.rented, color: "text-red-400" },
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="glass rounded-xl p-4"
              >
                <stat.icon className={`w-6 h-6 ${stat.color} mb-2`} />
                <p className="text-xl font-bold text-white">{stat.value}</p>
                <p className="text-xs text-neutral-500">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        ) : null}

        {/* Pending Orders */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-white mb-4">
            Đơn hàng chờ xác nhận
            {orders.length > 0 && (
              <span className="ml-2 px-2 py-0.5 rounded-full text-xs bg-orange-400/10 text-orange-400">
                {orders.length}
              </span>
            )}
          </h2>

          {ordersLoading ? (
            <div className="skeleton h-40 rounded-xl" />
          ) : orders.length === 0 ? (
            <div className="glass rounded-xl p-8 text-center">
              <CheckCircle className="w-12 h-12 text-neutral-700 mx-auto mb-3" />
              <p className="text-neutral-500">Không có đơn hàng chờ xác nhận</p>
            </div>
          ) : (
            <div className="space-y-3">
              {orders.map((order) => (
                <motion.div
                  key={order.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="glass-strong rounded-xl p-5"
                >
                  <div className="flex items-center justify-between flex-wrap gap-4">
                    <div>
                      <p className="font-medium text-white">{order.orderCode}</p>
                      <p className="text-sm text-neutral-400">
                        {order.accountName || "Tài khoản"} • {order.hours} giờ • {formatCurrency(order.price)}
                      </p>
                      <p className="text-xs text-neutral-500 mt-1">
                        Khách: {order.userName || "N/A"} • {formatDate(order.createdAt)}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => handleConfirmOrder(order.id, "confirm")}
                        className="flex items-center gap-1.5 px-4 py-2 bg-green-500/10 text-green-400 border border-green-500/20 rounded-lg text-sm font-medium hover:bg-green-500/20 transition-all"
                      >
                        <CheckCircle className="w-4 h-4" /> Xác nhận
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => handleConfirmOrder(order.id, "reject")}
                        className="flex items-center gap-1.5 px-4 py-2 bg-red-500/10 text-red-400 border border-red-500/20 rounded-lg text-sm font-medium hover:bg-red-500/20 transition-all"
                      >
                        <XCircle className="w-4 h-4" /> Từ chối
                      </motion.button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Orders */}
        {data?.recentOrders && data.recentOrders.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-white mb-4">Đơn hàng gần đây</h2>
            <div className="glass rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/5">
                      <th className="text-left p-3 text-neutral-400 font-medium">Mã đơn</th>
                      <th className="text-left p-3 text-neutral-400 font-medium">Khách</th>
                      <th className="text-left p-3 text-neutral-400 font-medium">Acc</th>
                      <th className="text-left p-3 text-neutral-400 font-medium">Giá</th>
                      <th className="text-left p-3 text-neutral-400 font-medium">Trạng thái</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.recentOrders.map((order) => (
                      <tr key={order.id} className="border-b border-white/3 hover:bg-white/2">
                        <td className="p-3 text-white font-mono">{order.orderCode}</td>
                        <td className="p-3 text-neutral-300">{order.userName || "N/A"}</td>
                        <td className="p-3 text-neutral-300">{order.accountName || "N/A"}</td>
                        <td className="p-3 text-primary">{formatCurrency(order.price)}</td>
                        <td className="p-3">
                          <span className={`text-xs ${getStatusColor(order.status)}`}>
                            {getStatusLabel(order.status)}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
      <Footer />
    </main>
  );
}
