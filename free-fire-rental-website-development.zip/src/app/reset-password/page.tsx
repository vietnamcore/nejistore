"use client";

import { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Key, Loader2, Eye, EyeOff, CheckCircle } from "lucide-react";
import Link from "next/link";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

export default function ResetPasswordPage() {
  return (
    <Suspense fallback={
      <main className="aurora-bg min-h-screen">
        <Header />
        <div className="flex items-center justify-center min-h-screen pt-20 px-4">
          <Loader2 className="w-16 h-16 text-primary animate-spin" />
        </div>
        <Footer />
      </main>
    }>
      <ResetPasswordContent />
    </Suspense>
  );
}

function ResetPasswordContent() {
  const searchParams = useSearchParams();
  const token = searchParams.get("token");
  const router = useRouter();
  const [form, setForm] = useState({ password: "", confirmPassword: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) {
      setError("Token không hợp lệ");
      return;
    }
    if (form.password !== form.confirmPassword) {
      setError("Mật khẩu xác nhận không khớp");
      return;
    }
    setIsLoading(true);
    setError("");

    try {
      const res = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, password: form.password, confirmPassword: form.confirmPassword }),
      });
      const data = await res.json();
      if (data.success) {
        setIsSuccess(true);
      } else {
        setError(data.error || "Đặt lại mật khẩu thất bại");
      }
    } catch {
      setError("Lỗi kết nối");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="aurora-bg min-h-screen">
      <Header />
      <div className="flex items-center justify-center min-h-screen pt-20 px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
          <div className="glass-strong rounded-2xl p-8">
            {isSuccess ? (
              <div className="text-center">
                <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
                <h1 className="text-xl font-bold text-white mb-2">Đặt lại mật khẩu thành công!</h1>
                <p className="text-neutral-400 mb-6">Vui lòng đăng nhập với mật khẩu mới.</p>
                <Link href="/login" className="text-primary hover:text-primary-light">
                  Đăng nhập ngay →
                </Link>
              </div>
            ) : (
              <>
                <div className="text-center mb-8">
                  <Key className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h1 className="text-2xl font-bold text-white">Đặt lại mật khẩu</h1>
                </div>

                {error && (
                  <div className="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
                    {error}
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-neutral-300 mb-1.5">Mật khẩu mới</label>
                    <input
                      type={showPassword ? "text" : "password"}
                      value={form.password}
                      onChange={(e) => setForm((p) => ({ ...p, password: e.target.value }))}
                      required
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-neutral-600 focus:border-primary/50 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-neutral-300 mb-1.5">Xác nhận mật khẩu</label>
                    <input
                      type={showPassword ? "text" : "password"}
                      value={form.confirmPassword}
                      onChange={(e) => setForm((p) => ({ ...p, confirmPassword: e.target.value }))}
                      required
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-neutral-600 focus:border-primary/50 outline-none"
                    />
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3 bg-gradient-to-r from-primary to-primary-dark text-white font-semibold rounded-xl disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Key className="w-5 h-5" />}
                    Đặt lại mật khẩu
                  </motion.button>
                </form>
              </>
            )}
          </div>
        </motion.div>
      </div>
      <Footer />
    </main>
  );
}
