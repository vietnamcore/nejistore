"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Search, Package, Loader2 } from "lucide-react";
import Link from "next/link";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { useAuthStore } from "@/stores/auth-store";
import { formatCurrency, formatDate, getStatusLabel, getStatusColor } from "@/lib/utils";

export default function OrdersPage() {
  const { token } = useAuthStore();
  const [orders, setOrders] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (token) fetchOrders();
  }, [token]);

  const fetchOrders = async () => {
    try {
      const res = await fetch("/api/orders", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.success) setOrders(data.data);
    } catch (error) {
      console.error("Fetch orders error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredOrders = orders.filter(
    (o) =>
      o.orderCode.toLowerCase().includes(search.toLowerCase()) ||
      (o.accountName && o.accountName.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <main className="aurora-bg min-h-screen">
      <Header />
      <div className="max-w-4xl mx-auto px-4 sm:px-6 pt-28 pb-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">
            Tra Cứu <span className="text-primary">Đơn Thuê</span>
          </h1>
          <p className="text-neutral-400 mb-8">Tìm kiếm đơn hàng theo mã đơn hoặc tên tài khoản</p>

          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-500" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Nhập mã đơn hoặc tên tài khoản..."
              className="w-full pl-11 pr-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-neutral-600 focus:border-primary/50 outline-none"
            />
          </div>

          {isLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="skeleton h-20 rounded-xl" />
              ))}
            </div>
          ) : filteredOrders.length === 0 ? (
            <div className="glass rounded-xl p-12 text-center">
              <Package className="w-12 h-12 text-neutral-700 mx-auto mb-3" />
              <p className="text-neutral-500">Không tìm thấy đơn hàng</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredOrders.map((order, i) => (
                <motion.div
                  key={order.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.03 }}
                >
                  <Link href={`/orders/${order.id}`}>
                    <div className="glass rounded-xl p-4 hover:bg-white/5 transition-colors cursor-pointer">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-white">{order.accountName || "Tài khoản"}</p>
                          <p className="text-xs text-neutral-500">
                            {order.orderCode} • {order.hours} giờ • {formatDate(order.createdAt)}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium text-primary">{formatCurrency(order.price)}</p>
                          <p className={`text-xs ${getStatusColor(order.status)}`}>{getStatusLabel(order.status)}</p>
                        </div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
      <Footer />
    </main>
  );
}
