"use client";

import { useState, useEffect, use } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, Clock, Gamepad2, Package } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { useAuthStore } from "@/stores/auth-store";
import { formatCurrency, formatDate, getTimeRemaining, getStatusLabel, getStatusColor, getProgressPercentage } from "@/lib/utils";
import { SUPPORT_PHONE, SUPPORT_ZALO } from "@/lib/constants";

export default function OrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { token } = useAuthStore();
  const [order, setOrder] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [timeRemaining, setTimeRemaining] = useState({ total: 0, hours: 0, minutes: 0, seconds: 0, isExpired: false });

  useEffect(() => {
    if (token) fetchOrder();
  }, [token, id]);

  useEffect(() => {
    if (!order || order.status !== "active" || !order.expiresAt) return;

    const interval = setInterval(() => {
      setTimeRemaining(getTimeRemaining(order.expiresAt));
    }, 1000);

    setTimeRemaining(getTimeRemaining(order.expiresAt));
    return () => clearInterval(interval);
  }, [order]);

  const fetchOrder = async () => {
    try {
      const res = await fetch(`/api/orders/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.success) setOrder(data.data);
    } catch (error) {
      console.error("Fetch order error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <main className="aurora-bg min-h-screen">
        <Header />
        <div className="max-w-2xl mx-auto px-4 pt-28 pb-20">
          <div className="skeleton h-60 rounded-2xl" />
        </div>
        <Footer />
      </main>
    );
  }

  if (!order) {
    return (
      <main className="aurora-bg min-h-screen">
        <Header />
        <div className="max-w-2xl mx-auto px-4 pt-28 pb-20 text-center">
          <Package className="w-16 h-16 text-neutral-700 mx-auto mb-4" />
          <p className="text-neutral-500">Không tìm thấy đơn hàng</p>
        </div>
        <Footer />
      </main>
    );
  }

  return (
    <main className="aurora-bg min-h-screen">
      <Header />
      <div className="max-w-2xl mx-auto px-4 sm:px-6 pt-28 pb-20">
        <button
          onClick={() => window.history.back()}
          className="flex items-center gap-2 text-neutral-400 hover:text-white mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Quay lại
        </button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-strong rounded-2xl p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Gamepad2 className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-xl font-bold text-white">{order.account?.name || "Tài khoản"}</h1>
                <p className="text-sm text-neutral-500">{order.orderCode}</p>
              </div>
            </div>
            <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
              {getStatusLabel(order.status)}
            </span>
          </div>

          {/* Countdown Timer */}
          {order.status === "active" && order.expiresAt && (
            <div className="mb-6 p-4 rounded-xl bg-primary/5 border border-primary/10">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="w-5 h-5 text-primary" />
                <span className="text-sm text-primary font-medium">Thời gian còn lại</span>
              </div>
              <div className="flex items-center gap-3 text-white font-mono text-2xl">
                <div className="text-center">
                  <p className="bg-white/5 rounded-lg px-3 py-2">{String(timeRemaining.hours).padStart(2, "0")}</p>
                  <p className="text-xs text-neutral-500 mt-1">Giờ</p>
                </div>
                <span className="text-primary">:</span>
                <div className="text-center">
                  <p className="bg-white/5 rounded-lg px-3 py-2">{String(timeRemaining.minutes).padStart(2, "0")}</p>
                  <p className="text-xs text-neutral-500 mt-1">Phút</p>
                </div>
                <span className="text-primary">:</span>
                <div className="text-center">
                  <p className="bg-white/5 rounded-lg px-3 py-2">{String(timeRemaining.seconds).padStart(2, "0")}</p>
                  <p className="text-xs text-neutral-500 mt-1">Giây</p>
                </div>
              </div>

              {order.startedAt && (
                <div className="progress-bar mt-3">
                  <div
                    className="progress-bar-fill"
                    style={{ width: getProgressPercentage(new Date(order.startedAt), new Date(order.expiresAt)) + "%" }}
                  />
                </div>
              )}
            </div>
          )}

          {/* Receive Code */}
          {order.status === "active" && order.receiveCode && (
            <div className="mb-6 p-4 rounded-xl bg-green-500/5 border border-green-500/10">
              <p className="text-sm text-green-400 mb-2">🔑 Mã nhận tài khoản</p>
              <p className="text-2xl font-bold text-white font-mono text-center py-2">{order.receiveCode}</p>
              <p className="text-xs text-neutral-400 mt-2 text-center">
                Vui lòng gửi mã này qua Zalo hoặc số điện thoại hỗ trợ để nhận thông tin tài khoản.
              </p>
              <div className="flex items-center justify-center gap-4 mt-3">
                <a
                  href={`tel:${SUPPORT_PHONE}`}
                  className="text-xs text-primary hover:text-primary-light"
                >
                  📞 {SUPPORT_PHONE}
                </a>
                <a
                  href={SUPPORT_ZALO}
                  target="_blank"
                  className="text-xs text-primary hover:text-primary-light"
                >
                  💬 Zalo
                </a>
              </div>
            </div>
          )}

          {/* Order Details */}
          <div className="space-y-3">
            {[
              { label: "Mã đơn hàng", value: order.orderCode },
              { label: "Tài khoản", value: order.account?.name || "N/A" },
              { label: "Số giờ thuê", value: `${order.hours} giờ` },
              { label: "Giá thuê", value: formatCurrency(order.price) },
              { label: "Ngày tạo", value: formatDate(order.createdAt) },
              ...(order.startedAt ? [{ label: "Thời gian bắt đầu", value: formatDate(order.startedAt) }] : []),
              ...(order.expiresAt ? [{ label: "Thời gian kết thúc", value: formatDate(order.expiresAt) }] : []),
              { label: "Trạng thái", value: getStatusLabel(order.status) },
              { label: "Thanh toán", value: getStatusLabel(order.paymentStatus) },
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between py-2 border-b border-white/5">
                <span className="text-sm text-neutral-400">{item.label}</span>
                <span className="text-sm text-white font-medium">{item.value}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
      <Footer />
    </main>
  );
}
