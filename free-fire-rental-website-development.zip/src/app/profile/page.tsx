"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { User, Mail, Phone, Calendar, Shield, Edit3, Save, Loader2 } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { useAuthStore } from "@/stores/auth-store";
import { formatDate, formatCurrency } from "@/lib/utils";

interface ProfileData {
  id: string;
  email: string;
  username: string;
  fullName: string;
  phone: string | null;
  avatar: string | null;
  role: string;
  emailVerified: boolean;
  emailVerifiedAt: string | null;
  createdAt: string;
  stats: {
    totalOrders: number;
    totalSpent: number;
    activeOrders: number;
    nearestExpiry: string | null;
  };
}

export default function ProfilePage() {
  const { user, token } = useAuthStore();
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [editForm, setEditForm] = useState({ fullName: "", username: "", phone: "" });
  const [message, setMessage] = useState({ type: "", text: "" });

  useEffect(() => {
    if (token) fetchProfile();
  }, [token]);

  const fetchProfile = async () => {
    try {
      const res = await fetch("/api/user/profile", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.success) {
        setProfile(data.data);
        setEditForm({
          fullName: data.data.fullName,
          username: data.data.username,
          phone: data.data.phone || "",
        });
      }
    } catch (error) {
      console.error("Fetch profile error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    setMessage({ type: "", text: "" });

    try {
      const res = await fetch("/api/user/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(editForm),
      });
      const data = await res.json();
      if (data.success) {
        setMessage({ type: "success", text: "Cập nhật thành công" });
        setIsEditing(false);
        fetchProfile();
      } else {
        setMessage({ type: "error", text: data.error || "Cập nhật thất bại" });
      }
    } catch {
      setMessage({ type: "error", text: "Lỗi kết nối" });
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <main className="aurora-bg min-h-screen">
        <Header />
        <div className="max-w-2xl mx-auto px-4 pt-28 pb-20">
          <div className="skeleton h-40 rounded-2xl mb-6" />
          <div className="skeleton h-60 rounded-2xl" />
        </div>
        <Footer />
      </main>
    );
  }

  return (
    <main className="aurora-bg min-h-screen">
      <Header />
      <div className="max-w-2xl mx-auto px-4 sm:px-6 pt-28 pb-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {/* Profile Header */}
          <div className="glass-strong rounded-2xl p-8 mb-6 text-center">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-primary-dark flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">
              {profile?.fullName?.[0]?.toUpperCase() || "U"}
            </div>
            <h1 className="text-2xl font-bold text-white">{profile?.fullName}</h1>
            <p className="text-neutral-400">@{profile?.username}</p>
            <div className="flex items-center justify-center gap-2 mt-2">
              <span className={`px-2 py-0.5 rounded-full text-xs ${
                profile?.emailVerified ? "bg-green-400/10 text-green-400" : "bg-red-400/10 text-red-400"
              }`}>
                {profile?.emailVerified ? "✓ Đã xác thực" : "✗ Chưa xác thực"}
              </span>
              <span className="px-2 py-0.5 rounded-full text-xs bg-primary/10 text-primary">
                {profile?.role === "admin" ? "Admin" : "User"}
              </span>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            {[
              { label: "Tổng đơn", value: profile?.stats.totalOrders || 0 },
              { label: "Tổng tiền", value: formatCurrency(profile?.stats.totalSpent || 0) },
              { label: "Đang thuê", value: profile?.stats.activeOrders || 0 },
            ].map((stat, i) => (
              <div key={i} className="glass rounded-xl p-4 text-center">
                <p className="text-lg font-bold text-white">{stat.value}</p>
                <p className="text-xs text-neutral-500">{stat.label}</p>
              </div>
            ))}
          </div>

          {/* Profile Info */}
          <div className="glass-strong rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-white">Thông tin cá nhân</h2>
              {!isEditing ? (
                <button
                  onClick={() => setIsEditing(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm text-primary hover:bg-primary/10 transition-colors"
                >
                  <Edit3 className="w-4 h-4" /> Chỉnh sửa
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsEditing(false)}
                    className="px-3 py-1.5 rounded-lg text-sm text-neutral-400 hover:text-white"
                  >
                    Hủy
                  </button>
                  <button
                    onClick={handleSave}
                    disabled={isSaving}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm bg-primary text-white hover:bg-primary-dark disabled:opacity-50"
                  >
                    {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                    Lưu
                  </button>
                </div>
              )}
            </div>

            {message.text && (
              <div className={`mb-4 p-3 rounded-lg text-sm ${
                message.type === "success" ? "bg-green-500/10 text-green-400" : "bg-red-500/10 text-red-400"
              }`}>
                {message.text}
              </div>
            )}

            <div className="space-y-4">
              <ProfileField
                icon={User}
                label="Họ và tên"
                value={isEditing ? editForm.fullName : profile?.fullName || ""}
                isEditing={isEditing}
                editValue={editForm.fullName}
                onChange={(v) => setEditForm((p) => ({ ...p, fullName: v }))}
              />
              <ProfileField
                icon={User}
                label="Username"
                value={isEditing ? editForm.username : profile?.username || ""}
                isEditing={isEditing}
                editValue={editForm.username}
                onChange={(v) => setEditForm((p) => ({ ...p, username: v }))}
              />
              <ProfileField
                icon={Mail}
                label="Email"
                value={profile?.email || ""}
                isEditing={false}
                editValue=""
                onChange={() => {}}
                disabled
              />
              <ProfileField
                icon={Phone}
                label="Số điện thoại"
                value={isEditing ? editForm.phone : profile?.phone || ""}
                isEditing={isEditing}
                editValue={editForm.phone}
                onChange={(v) => setEditForm((p) => ({ ...p, phone: v }))}
              />
              <ProfileField
                icon={Calendar}
                label="Ngày tạo"
                value={profile?.createdAt ? formatDate(profile.createdAt) : ""}
                isEditing={false}
                editValue=""
                onChange={() => {}}
                disabled
              />
              <ProfileField
                icon={Shield}
                label="Xác thực email"
                value={profile?.emailVerifiedAt ? formatDate(profile.emailVerifiedAt) : "Chưa xác thực"}
                isEditing={false}
                editValue=""
                onChange={() => {}}
                disabled
              />
            </div>
          </div>
        </motion.div>
      </div>
      <Footer />
    </main>
  );
}

function ProfileField({
  icon: Icon,
  label,
  value,
  isEditing,
  editValue,
  onChange,
  disabled,
}: {
  icon: any;
  label: string;
  value: string;
  isEditing: boolean;
  editValue: string;
  onChange: (v: string) => void;
  disabled?: boolean;
}) {
  return (
    <div className="flex items-center gap-3">
      <Icon className="w-5 h-5 text-neutral-500 shrink-0" />
      <div className="flex-1">
        <p className="text-xs text-neutral-500">{label}</p>
        {isEditing && !disabled ? (
          <input
            type="text"
            value={editValue}
            onChange={(e) => onChange(e.target.value)}
            className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm focus:border-primary/50 outline-none"
          />
        ) : (
          <p className={`text-sm ${disabled ? "text-neutral-500" : "text-white"}`}>{value}</p>
        )}
      </div>
    </div>
  );
}
