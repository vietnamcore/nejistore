"use client";

import { motion } from "framer-motion";
import { Phone, Mail, MessageCircle, Clock, MapPin } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { SUPPORT_PHONE, SUPPORT_EMAIL, SUPPORT_ZALO } from "@/lib/constants";

export default function ContactPage() {
  return (
    <main className="aurora-bg min-h-screen">
      <Header />
      <div className="max-w-4xl mx-auto px-4 sm:px-6 pt-28 pb-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2 text-center">
            Liên <span className="text-primary">Hệ</span>
          </h1>
          <p className="text-neutral-400 text-center mb-12">Liên hệ với chúng tôi bất cứ lúc nào</p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-12">
            {[
              { icon: Phone, title: "Điện thoại", value: SUPPORT_PHONE, href: `tel:${SUPPORT_PHONE}`, desc: "Hotline hỗ trợ 24/7" },
              { icon: MessageCircle, title: "Zalo", value: "Nhắn tin Zalo", href: SUPPORT_ZALO, desc: "Phản hồi nhanh chóng" },
              { icon: Mail, title: "Email", value: SUPPORT_EMAIL, href: `mailto:${SUPPORT_EMAIL}`, desc: "Phản hồi trong 24h" },
            ].map((item, i) => (
              <motion.a
                key={i}
                href={item.href}
                target={item.href.startsWith("http") ? "_blank" : undefined}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -5, scale: 1.02 }}
                className="glass rounded-2xl p-6 text-center hover:glow-green transition-all duration-300"
              >
                <item.icon className="w-10 h-10 text-primary mx-auto mb-4" />
                <h3 className="font-semibold text-white mb-1">{item.title}</h3>
                <p className="text-primary font-medium mb-1">{item.value}</p>
                <p className="text-xs text-neutral-500">{item.desc}</p>
              </motion.a>
            ))}
          </div>

          <div className="glass-strong rounded-2xl p-8">
            <h2 className="text-xl font-bold text-white mb-6">Giờ làm việc</h2>
            <div className="space-y-3">
              {[
                { day: "Thứ 2 - Thứ 6", time: "8:00 - 22:00" },
                { day: "Thứ 7", time: "9:00 - 22:00" },
                { day: "Chủ nhật", time: "9:00 - 21:00" },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between py-2 border-b border-white/5">
                  <span className="text-neutral-400">{item.day}</span>
                  <span className="text-white font-medium">{item.time}</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
      <Footer />
    </main>
  );
}
