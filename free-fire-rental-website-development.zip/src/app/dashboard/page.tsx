"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Gamepad2,
  Clock,
  CreditCard,
  Package,
  User,
  Key,
  Bell,
  Loader2,
  CheckCircle,
  AlertCircle,
  XCircle,
} from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { useAuthStore } from "@/stores/auth-store";
import { formatCurrency, formatDate, getTimeRemaining, getStatusLabel, getStatusColor } from "@/lib/utils";

interface OrderItem {
  id: string;
  orderCode: string;
  receiveCode: string;
  accountId: string;
  hours: number;
  price: number;
  status: string;
  startedAt: string | null;
  expiresAt: string | null;
  createdAt: string;
  accountName: string | null;
}

export default function DashboardPage() {
  const { user, token } = useAuthStore();
  const [orders, setOrders] = useState<OrderItem[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"overview" | "orders" | "notifications">("overview");

  useEffect(() => {
    if (token) {
      fetchData();
    }
  }, [token]);

  const fetchData = async () => {
    try {
      const [ordersRes, notifRes] = await Promise.all([
        fetch("/api/orders", { headers: { Authorization: `Bearer ${token}` } }),
        fetch("/api/notifications", { headers: { Authorization: `Bearer ${token}` } }),
      ]);

      const ordersData = await ordersRes.json();
      const notifData = await notifRes.json();

      if (ordersData.success) setOrders(ordersData.data);
      if (notifData.success) setNotifications(notifData.data);
    } catch (error) {
      console.error("Fetch data error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const activeOrders = orders.filter((o) => o.status === "active");
  const totalSpent = orders
    .filter((o) => o.status === "active" || o.status === "completed")
    .reduce((sum, o) => sum + o.price, 0);
  const unreadNotifs = notifications.filter((n) => !n.isRead);

  if (!user) {
    return (
      <main className="aurora-bg min-h-screen">
        <Header />
        <div className="flex items-center justify-center min-h-screen">
          <p className="text-neutral-400">Vui lòng đăng nhập</p>
        </div>
        <Footer />
      </main>
    );
  }

  return (
    <main className="aurora-bg min-h-screen">
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-20">
        {/* Welcome */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-2xl sm:text-3xl font-bold text-white">
            Xin chào, <span className="text-primary">{user.fullName}</span>! 👋
          </h1>
          <p className="text-neutral-400 mt-1">Chào mừng bạn đến với FF Rent</p>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { icon: Package, label: "Đang thuê", value: activeOrders.length, color: "text-green-400" },
            { icon: CreditCard, label: "Tổng đơn", value: orders.length, color: "text-blue-400" },
            { icon: CreditCard, label: "Tổng tiền", value: formatCurrency(totalSpent), color: "text-primary" },
            { icon: Bell, label: "Thông báo", value: unreadNotifs.length, color: "text-yellow-400" },
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="glass rounded-xl p-4"
            >
              <stat.icon className={`w-6 h-6 ${stat.color} mb-2`} />
              <p className="text-2xl font-bold text-white">{stat.value}</p>
              <p className="text-xs text-neutral-500">{stat.label}</p>
            </motion.div>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap gap-3 mb-8">
          {[
            { href: "/accounts", label: "Thuê ngay", icon: Gamepad2, primary: true },
            { href: "/orders", label: "Tra cứu đơn", icon: Package },
            { href: "/history", label: "Lịch sử thuê", icon: Clock },
            { href: "/profile", label: "Hồ sơ", icon: User },
            { href: "/change-password", label: "Đổi mật khẩu", icon: Key },
          ].map((action, i) => (
            <Link key={i} href={action.href}>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  action.primary
                    ? "bg-gradient-to-r from-primary to-primary-dark text-white"
                    : "glass text-neutral-300 hover:text-white"
                }`}
              >
                <action.icon className="w-4 h-4" />
                {action.label}
              </motion.button>
            </Link>
          ))}
        </div>

        {/* Active Orders */}
        {activeOrders.length > 0 && (
          <div className="mb-8">
            <h2 className="text-lg font-semibold text-white mb-4">Tài khoản đang thuê</h2>
            <div className="space-y-4">
              {activeOrders.map((order) => (
                <ActiveOrderCard key={order.id} order={order} />
              ))}
            </div>
          </div>
        )}

        {/* Recent Orders */}
        <div>
          <h2 className="text-lg font-semibold text-white mb-4">Đơn hàng gần đây</h2>
          {isLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="skeleton h-20 rounded-xl" />
              ))}
            </div>
          ) : orders.length === 0 ? (
            <div className="glass rounded-xl p-8 text-center">
              <Package className="w-12 h-12 text-neutral-700 mx-auto mb-3" />
              <p className="text-neutral-500">Chưa có đơn hàng nào</p>
              <Link href="/accounts" className="text-primary text-sm mt-2 inline-block">
                Thuê ngay →
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {orders.slice(0, 10).map((order) => (
                <motion.div
                  key={order.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="glass rounded-xl p-4 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-2 h-2 rounded-full ${
                      order.status === "active" ? "bg-green-400" :
                      order.status === "pending_payment" || order.status === "awaiting_confirmation" ? "bg-yellow-400" :
                      order.status === "completed" ? "bg-blue-400" : "bg-neutral-500"
                    }`} />
                    <div>
                      <p className="text-sm font-medium text-white">{order.accountName || "Tài khoản"}</p>
                      <p className="text-xs text-neutral-500">{order.orderCode} • {order.hours} giờ</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-primary">{formatCurrency(order.price)}</p>
                    <p className={`text-xs ${getStatusColor(order.status)}`}>{getStatusLabel(order.status)}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
      <Footer />
    </main>
  );
}

function ActiveOrderCard({ order }: { order: OrderItem }) {
  const [timeRemaining, setTimeRemaining] = useState(
    getTimeRemaining(order.expiresAt || "")
  );

  useEffect(() => {
    if (!order.expiresAt) return;

    const interval = setInterval(() => {
      setTimeRemaining(getTimeRemaining(order.expiresAt || ""));
    }, 1000);

    return () => clearInterval(interval);
  }, [order.expiresAt]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-strong rounded-xl p-5 border-animate"
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <Gamepad2 className="w-6 h-6 text-primary" />
          <div>
            <p className="font-medium text-white">{order.accountName}</p>
            <p className="text-xs text-neutral-500">{order.orderCode}</p>
          </div>
        </div>
        <span className="px-2 py-1 rounded-full text-xs bg-green-400/10 text-green-400 border border-green-400/20">
          Đang thuê
        </span>
      </div>

      <div className="flex items-center gap-2 text-white font-mono text-lg mb-2">
        <Clock className="w-5 h-5 text-primary" />
        {String(timeRemaining.hours).padStart(2, "0")} giờ{" "}
        {String(timeRemaining.minutes).padStart(2, "0")} phút{" "}
        {String(timeRemaining.seconds).padStart(2, "0")} giây
      </div>

      <div className="progress-bar mb-3">
        <div
          className="progress-bar-fill"
          style={{ width: order.startedAt && order.expiresAt ? Math.min(100, ((Date.now() - new Date(order.startedAt).getTime()) / (new Date(order.expiresAt).getTime() - new Date(order.startedAt).getTime())) * 100) + "%" : "0%" }}
        />
      </div>

      <div className="flex items-center justify-between">
        <p className="text-sm text-neutral-400">
          Mã nhận: <span className="text-primary font-mono">{order.receiveCode}</span>
        </p>
        <Link href={`/orders/${order.id}`}>
          <button className="text-xs text-primary hover:text-primary-light">Chi tiết →</button>
        </Link>
      </div>
    </motion.div>
  );
}
