"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Gamepad2, ArrowRight } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { formatCurrency } from "@/lib/utils";
import { DEFAULT_ACCOUNTS } from "@/lib/constants";

export default function PricingPage() {
  return (
    <main className="aurora-bg min-h-screen">
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-28 pb-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="text-center mb-12">
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Bảng Giá <span className="text-primary">Thuê Acc</span>
            </h1>
            <p className="text-neutral-400">Giá thuê theo giờ, không phát sinh phí</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {DEFAULT_ACCOUNTS.map((acc, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -5 }}
                className="glass rounded-2xl p-6 hover:glow-green transition-all duration-300"
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                    <Gamepad2 className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white">{acc.name}</h3>
                    <p className="text-xs text-neutral-500">Rank: {acc.rank}</p>
                  </div>
                </div>

                <div className="space-y-3 mb-6">
                  {acc.pricing.map((p, j) => (
                    <div
                      key={j}
                      className={`flex items-center justify-between p-3 rounded-xl ${
                        j === 2 ? "bg-primary/5 border border-primary/10" : "bg-white/3"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-neutral-400">{p.hours} giờ</span>
                        {j === 2 && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-primary/10 text-primary">Phổ biến</span>
                        )}
                      </div>
                      <span className="text-primary font-bold">{formatCurrency(p.price)}</span>
                    </div>
                  ))}
                </div>

                <Link href="/accounts">
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full py-3 bg-gradient-to-r from-primary to-primary-dark text-white font-medium rounded-xl hover:shadow-lg hover:shadow-primary/20 transition-all flex items-center justify-center gap-2 text-sm"
                  >
                    Thuê ngay <ArrowRight className="w-4 h-4" />
                  </motion.button>
                </Link>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
      <Footer />
    </main>
  );
}
