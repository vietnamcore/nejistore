"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Mail, Loader2, Gamepad2, ArrowLeft } from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSent, setIsSent] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      const res = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (data.success) {
        setIsSent(true);
      } else {
        setError(data.error || "Gửi yêu cầu thất bại");
      }
    } catch {
      setError("Lỗi kết nối");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="aurora-bg min-h-screen">
      <Header />
      <div className="flex items-center justify-center min-h-screen pt-20 px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          <div className="glass-strong rounded-2xl p-8">
            {isSent ? (
              <div className="text-center">
                <Mail className="w-16 h-16 text-primary mx-auto mb-4" />
                <h1 className="text-2xl font-bold text-white mb-2">Kiểm tra email</h1>
                <p className="text-neutral-400 mb-6">
                  Nếu email tồn tại trong hệ thống, bạn sẽ nhận được liên kết đặt lại mật khẩu.
                </p>
                <Link href="/login" className="text-primary hover:text-primary-light">
                  Quay lại đăng nhập
                </Link>
              </div>
            ) : (
              <>
                <div className="text-center mb-8">
                  <Gamepad2 className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h1 className="text-2xl font-bold text-white">Quên mật khẩu</h1>
                  <p className="text-sm text-neutral-500 mt-2">Nhập email để nhận liên kết đặt lại</p>
                </div>

                {error && (
                  <div className="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
                    {error}
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-neutral-300 mb-1.5">Email</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-neutral-600 focus:border-primary/50 focus:ring-1 focus:ring-primary/30 outline-none transition-all"
                      placeholder="email@example.com"
                    />
                  </div>

                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3 bg-gradient-to-r from-primary to-primary-dark text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-primary/20 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Mail className="w-5 h-5" />}
                    Gửi yêu cầu
                  </motion.button>
                </form>

                <div className="text-center mt-6">
                  <Link href="/login" className="text-sm text-neutral-400 hover:text-primary inline-flex items-center gap-1">
                    <ArrowLeft className="w-4 h-4" /> Quay lại đăng nhập
                  </Link>
                </div>
              </>
            )}
          </div>
        </motion.div>
      </div>
      <Footer />
    </main>
  );
}
