import { NextResponse } from "next/server";
import { db } from "@/db";
import { rentalOrders, ffAccounts, users, notifications, auditLogs } from "@/db/schema";
import { getAdminFromRequest } from "@/lib/auth";
import { adminConfirmOrderSchema } from "@/lib/validations";
import { eq, desc, and, sql } from "drizzle-orm";
import { getClientIp } from "@/lib/utils";

// Get all orders (admin)
export async function GET(request: Request) {
  try {
    const { user, error } = await getAdminFromRequest(request);
    if (error || !user) {
      return NextResponse.json(
        { success: false, error: "Admin access required" },
        { status: 403 }
      );
    }

    const url = new URL(request.url);
    const status = url.searchParams.get("status");

    let orders;

    if (status && status !== "all") {
      orders = await db
        .select({
          order: rentalOrders,
          accountName: ffAccounts.name,
          accountImageUrl: ffAccounts.imageUrl,
          userName: users.fullName,
          userEmail: users.email,
          userUsername: users.username,
        })
        .from(rentalOrders)
        .leftJoin(ffAccounts, eq(rentalOrders.accountId, ffAccounts.id))
        .leftJoin(users, eq(rentalOrders.userId, users.id))
        .where(eq(rentalOrders.status, status as "pending_payment" | "awaiting_confirmation" | "active" | "completed" | "expired" | "cancelled"))
        .orderBy(desc(rentalOrders.createdAt));
    } else {
      orders = await db
        .select({
          order: rentalOrders,
          accountName: ffAccounts.name,
          accountImageUrl: ffAccounts.imageUrl,
          userName: users.fullName,
          userEmail: users.email,
          userUsername: users.username,
        })
        .from(rentalOrders)
        .leftJoin(ffAccounts, eq(rentalOrders.accountId, ffAccounts.id))
        .leftJoin(users, eq(rentalOrders.userId, users.id))
        .orderBy(desc(rentalOrders.createdAt));
    }

    const formattedOrders = orders.map((o) => ({
      ...o.order,
      accountName: o.accountName,
      accountImageUrl: o.accountImageUrl,
      userName: o.userName,
      userEmail: o.userEmail,
      userUsername: o.userUsername,
    }));

    return NextResponse.json({
      success: true,
      data: formattedOrders,
    });
  } catch (error) {
    console.error("Admin get orders error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống" },
      { status: 500 }
    );
  }
}

// Admin confirm or reject order
export async function PUT(request: Request) {
  try {
    const { user, error } = await getAdminFromRequest(request);
    if (error || !user) {
      return NextResponse.json(
        { success: false, error: "Admin access required" },
        { status: 403 }
      );
    }

    const body = await request.json();
    const validated = adminConfirmOrderSchema.safeParse(body);

    if (!validated.success) {
      return NextResponse.json(
        { success: false, error: validated.error.issues.map((i) => i.message).join(", ") },
        { status: 400 }
      );
    }

    const { orderId, action, reason } = validated.data;

    const order = await db
      .select()
      .from(rentalOrders)
      .where(eq(rentalOrders.id, orderId))
      .limit(1);

    if (order.length === 0) {
      return NextResponse.json(
        { success: false, error: "Không tìm thấy đơn hàng" },
        { status: 404 }
      );
    }

    const o = order[0];
    const ip = getClientIp(request);

    if (action === "confirm") {
      if (o.status !== "awaiting_confirmation") {
        return NextResponse.json(
          { success: false, error: "Đơn hàng không ở trạng thái chờ xác nhận" },
          { status: 400 }
        );
      }

      // Check if this is an extension
      if (o.isExtension && o.parentOrderId) {
        // Find parent order
        const parentOrder = await db
          .select()
          .from(rentalOrders)
          .where(eq(rentalOrders.id, o.parentOrderId))
          .limit(1);

        if (parentOrder.length > 0 && parentOrder[0].status === "active") {
          // Extend the parent order's expiration time
          const newExpiresAt = new Date(parentOrder[0].expiresAt!);
          newExpiresAt.setHours(newExpiresAt.getHours() + o.hours);

          await db
            .update(rentalOrders)
            .set({ expiresAt: newExpiresAt })
            .where(eq(rentalOrders.id, o.parentOrderId));

          // Update account expiration
          await db
            .update(ffAccounts)
            .set({ currentExpiresAt: newExpiresAt })
            .where(eq(ffAccounts.id, o.accountId));

          // Mark extension order as completed
          await db
            .update(rentalOrders)
            .set({
              status: "completed",
              paymentStatus: "confirmed",
              paymentConfirmedAt: new Date(),
              paymentConfirmedBy: user.id,
              startedAt: parentOrder[0].startedAt,
              expiresAt: newExpiresAt,
              completedAt: new Date(),
            })
            .where(eq(rentalOrders.id, orderId));
        }
      } else {
        // Start the rental
        const now = new Date();
        const expiresAt = new Date(now);
        expiresAt.setHours(expiresAt.getHours() + o.hours);

        await db
          .update(rentalOrders)
          .set({
            status: "active",
            paymentStatus: "confirmed",
            paymentConfirmedAt: new Date(),
            paymentConfirmedBy: user.id,
            startedAt: now,
            expiresAt,
          })
          .where(eq(rentalOrders.id, orderId));

        // Update account status
        await db
          .update(ffAccounts)
          .set({
            status: "rented",
            currentRenterId: o.userId,
            currentOrderId: orderId,
            currentExpiresAt: expiresAt,
          })
          .where(eq(ffAccounts.id, o.accountId));
      }

      // Notify user
      await db.insert(notifications).values({
        userId: o.userId,
        title: "✅ Thanh toán đã được xác nhận",
        message: `Đơn hàng ${o.orderCode} - Admin đã xác nhận thanh toán. Tài khoản đang được thuê. Mã nhận tài khoản: ${o.receiveCode}`,
        type: "payment",
        relatedId: orderId,
      });

      // Audit log
      await db.insert(auditLogs).values({
        userId: user.id,
        action: "order_confirmed",
        entity: "rental_order",
        entityId: orderId,
        ip,
      });

      return NextResponse.json({
        success: true,
        message: "Đã xác nhận đơn hàng thành công",
      });
    } else if (action === "reject") {
      // Reject order
      await db
        .update(rentalOrders)
        .set({
          status: "cancelled",
          paymentStatus: "rejected",
          cancelledAt: new Date(),
          cancelReason: reason || "Admin từ chối",
        })
        .where(eq(rentalOrders.id, orderId));

      // Release account
      if (!o.isExtension) {
        await db
          .update(ffAccounts)
          .set({ status: "available", currentRenterId: null, currentOrderId: null })
          .where(eq(ffAccounts.id, o.accountId));
      }

      // Notify user
      await db.insert(notifications).values({
        userId: o.userId,
        title: "❌ Đơn hàng bị từ chối",
        message: `Đơn hàng ${o.orderCode} đã bị từ chối. Lý do: ${reason || "Không hợp lệ"}. Vui lòng liên hệ Admin để biết thêm chi tiết.`,
        type: "payment",
        relatedId: orderId,
      });

      // Audit log
      await db.insert(auditLogs).values({
        userId: user.id,
        action: "order_rejected",
        entity: "rental_order",
        entityId: orderId,
        details: reason,
        ip,
      });

      return NextResponse.json({
        success: true,
        message: "Đã từ chối đơn hàng",
      });
    }

    return NextResponse.json(
      { success: false, error: "Hành động không hợp lệ" },
      { status: 400 }
    );
  } catch (error) {
    console.error("Admin confirm order error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống" },
      { status: 500 }
    );
  }
}
