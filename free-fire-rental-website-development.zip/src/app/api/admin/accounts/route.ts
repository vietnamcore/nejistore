import { NextResponse } from "next/server";
import { db } from "@/db";
import { ffAccounts, pricing } from "@/db/schema";
import { getAdminFromRequest } from "@/lib/auth";
import { adminUpdateAccountSchema, adminUpdatePricingSchema } from "@/lib/validations";
import { eq, asc } from "drizzle-orm";

// Get all accounts (admin, includes game credentials)
export async function GET(request: Request) {
  try {
    const { user, error } = await getAdminFromRequest(request);
    if (error || !user) {
      return NextResponse.json(
        { success: false, error: "Admin access required" },
        { status: 403 }
      );
    }

    const accounts = await db
      .select()
      .from(ffAccounts)
      .orderBy(asc(ffAccounts.sortOrder));

    const allPricing = await db
      .select()
      .from(pricing)
      .orderBy(asc(pricing.hours));

    const accountsWithPricing = accounts.map((account) => ({
      ...account,
      pricing: allPricing.filter((p) => p.accountId === account.id),
    }));

    return NextResponse.json({
      success: true,
      data: accountsWithPricing,
    });
  } catch (error) {
    console.error("Admin get accounts error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống" },
      { status: 500 }
    );
  }
}

// Update account
export async function PUT(request: Request) {
  try {
    const { user, error } = await getAdminFromRequest(request);
    if (error || !user) {
      return NextResponse.json(
        { success: false, error: "Admin access required" },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { accountId, ...updateData } = body;

    if (!accountId) {
      return NextResponse.json(
        { success: false, error: "ID tài khoản không hợp lệ" },
        { status: 400 }
      );
    }

    const validated = adminUpdateAccountSchema.safeParse(updateData);
    if (!validated.success) {
      return NextResponse.json(
        { success: false, error: validated.error.issues.map((i) => i.message).join(", ") },
        { status: 400 }
      );
    }

    await db
      .update(ffAccounts)
      .set({ ...validated.data, updatedAt: new Date() })
      .where(eq(ffAccounts.id, accountId));

    return NextResponse.json({
      success: true,
      message: "Cập nhật tài khoản thành công",
    });
  } catch (error) {
    console.error("Admin update account error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống" },
      { status: 500 }
    );
  }
}

// Update pricing
export async function PATCH(request: Request) {
  try {
    const { user, error } = await getAdminFromRequest(request);
    if (error || !user) {
      return NextResponse.json(
        { success: false, error: "Admin access required" },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { accountId, pricingData } = body;

    if (!accountId) {
      return NextResponse.json(
        { success: false, error: "ID tài khoản không hợp lệ" },
        { status: 400 }
      );
    }

    // Delete existing pricing
    await db.delete(pricing).where(eq(pricing.accountId, accountId));

    // Insert new pricing
    if (pricingData && pricingData.length > 0) {
      for (const p of pricingData) {
        await db.insert(pricing).values({
          accountId,
          hours: p.hours,
          price: p.price,
          isActive: true,
        });
      }
    }

    return NextResponse.json({
      success: true,
      message: "Cập nhật bảng giá thành công",
    });
  } catch (error) {
    console.error("Admin update pricing error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống" },
      { status: 500 }
    );
  }
}
