import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, rentalOrders, ffAccounts } from "@/db/schema";
import { getAdminFromRequest } from "@/lib/auth";
import { eq, sql, and } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    const { user, error } = await getAdminFromRequest(request);
    if (error || !user) {
      return NextResponse.json({ success: false, error: "Admin access required" }, { status: 403 });
    }

    // Total users
    const totalUsers = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(users)
      .where(eq(users.role, "user"));

    // Total orders
    const orderStats = await db
      .select({
        total: sql<number>`count(*)::int`,
        pending: sql<number>`count(*) filter (where ${rentalOrders.status} = 'pending_payment')::int`,
        awaiting: sql<number>`count(*) filter (where ${rentalOrders.status} = 'awaiting_confirmation')::int`,
        active: sql<number>`count(*) filter (where ${rentalOrders.status} = 'active')::int`,
        completed: sql<number>`count(*) filter (where ${rentalOrders.status} = 'completed')::int`,
        totalRevenue: sql<number>`coalesce(sum(${rentalOrders.price}) filter (where ${rentalOrders.paymentStatus} = 'confirmed'), 0)::int`,
      })
      .from(rentalOrders);

    // Account stats
    const accountStats = await db
      .select({
        total: sql<number>`count(*)::int`,
        available: sql<number>`count(*) filter (where ${ffAccounts.status} = 'available')::int`,
        rented: sql<number>`count(*) filter (where ${ffAccounts.status} = 'rented')::int`,
        maintenance: sql<number>`count(*) filter (where ${ffAccounts.status} = 'maintenance')::int`,
      })
      .from(ffAccounts);

    // Recent orders
    const recentOrders = await db
      .select({
        id: rentalOrders.id,
        orderCode: rentalOrders.orderCode,
        status: rentalOrders.status,
        price: rentalOrders.price,
        hours: rentalOrders.hours,
        createdAt: rentalOrders.createdAt,
        accountName: ffAccounts.name,
        userName: users.fullName,
      })
      .from(rentalOrders)
      .leftJoin(ffAccounts, eq(rentalOrders.accountId, ffAccounts.id))
      .leftJoin(users, eq(rentalOrders.userId, users.id))
      .orderBy(sql`${rentalOrders.createdAt} DESC`)
      .limit(10);

    return NextResponse.json({
      success: true,
      data: {
        totalUsers: totalUsers[0]?.count || 0,
        orderStats: orderStats[0] || {},
        accountStats: accountStats[0] || {},
        recentOrders,
      },
    });
  } catch (error) {
    console.error("Admin dashboard error:", error);
    return NextResponse.json({ success: false, error: "Lỗi hệ thống" }, { status: 500 });
  }
}
