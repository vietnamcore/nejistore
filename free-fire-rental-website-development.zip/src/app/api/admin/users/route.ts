import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, rentalOrders } from "@/db/schema";
import { getAdminFromRequest } from "@/lib/auth";
import { adminUpdateUserSchema } from "@/lib/validations";
import { eq, desc, sql } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    const { user, error } = await getAdminFromRequest(request);
    if (error || !user) {
      return NextResponse.json({ success: false, error: "Admin access required" }, { status: 403 });
    }

    const allUsers = await db
      .select({
        id: users.id,
        email: users.email,
        username: users.username,
        fullName: users.fullName,
        phone: users.phone,
        avatar: users.avatar,
        role: users.role,
        emailVerified: users.emailVerified,
        isActive: users.isActive,
        createdAt: users.createdAt,
        lastLoginAt: users.lastLoginAt,
      })
      .from(users)
      .orderBy(desc(users.createdAt));

    return NextResponse.json({ success: true, data: allUsers });
  } catch (error) {
    console.error("Admin get users error:", error);
    return NextResponse.json({ success: false, error: "Lỗi hệ thống" }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const { user, error } = await getAdminFromRequest(request);
    if (error || !user) {
      return NextResponse.json({ success: false, error: "Admin access required" }, { status: 403 });
    }

    const body = await request.json();
    const { userId, ...updateData } = body;

    if (!userId) {
      return NextResponse.json({ success: false, error: "ID người dùng không hợp lệ" }, { status: 400 });
    }

    const validated = adminUpdateUserSchema.safeParse(updateData);
    if (!validated.success) {
      return NextResponse.json({ success: false, error: validated.error.issues.map((i) => i.message).join(", ") }, { status: 400 });
    }

    await db
      .update(users)
      .set({ ...validated.data, updatedAt: new Date() })
      .where(eq(users.id, userId));

    return NextResponse.json({ success: true, message: "Cập nhật người dùng thành công" });
  } catch (error) {
    console.error("Admin update user error:", error);
    return NextResponse.json({ success: false, error: "Lỗi hệ thống" }, { status: 500 });
  }
}
