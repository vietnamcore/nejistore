import { NextResponse } from "next/server";
import { db } from "@/db";
import { rentalOrders, ffAccounts, notifications } from "@/db/schema";
import { eq, and, lt, sql } from "drizzle-orm";

// Cron job to expire orders and release accounts
// This should be called periodically (e.g., every minute)
export async function GET(request: Request) {
  try {
    // Verify cron secret
    const authHeader = request.headers.get("authorization");
    const cronSecret = process.env.CRON_SECRET || "ff-rent-cron-secret";
    if (authHeader !== `Bearer ${cronSecret}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const now = new Date();
    let expiredCount = 0;
    let cancelledCount = 0;

    // 1. Expire active orders that have passed their expiration time
    const expiredOrders = await db
      .select()
      .from(rentalOrders)
      .where(
        and(
          eq(rentalOrders.status, "active"),
          lt(rentalOrders.expiresAt, now)
        )
      );

    for (const order of expiredOrders) {
      // Mark order as expired
      await db
        .update(rentalOrders)
        .set({
          status: "expired",
          completedAt: now,
        })
        .where(eq(rentalOrders.id, order.id));

      // Release account
      await db
        .update(ffAccounts)
        .set({
          status: "available",
          currentRenterId: null,
          currentOrderId: null,
          currentExpiresAt: null,
        })
        .where(eq(ffAccounts.id, order.accountId));

      // Notify user
      await db.insert(notifications).values({
        userId: order.userId,
        title: "⏰ Đã hết thời gian thuê",
        message: `Đơn hàng ${order.orderCode} đã hết thời gian thuê. Tài khoản đã được trả về.`,
        type: "order",
        relatedId: order.id,
      });

      // Notify admin
      const { users: usersTable } = await import("@/db/schema");
      const admins = await db
        .select({ id: usersTable.id })
        .from(usersTable)
        .where(eq(usersTable.role, "admin"));

      for (const admin of admins) {
        await db.insert(notifications).values({
          userId: admin.id,
          title: "🔓 Tài khoản đã được giải phóng",
          message: `Đơn hàng ${order.orderCode} đã hết hạn. Tài khoản đã tự động chuyển về trạng thái Có sẵn.`,
          type: "account",
          relatedId: order.id,
        });
      }

      expiredCount++;
    }

    // 2. Cancel pending_payment orders that have exceeded hold period
    const cancelledOrders = await db
      .select()
      .from(rentalOrders)
      .where(
        and(
          eq(rentalOrders.status, "pending_payment"),
          lt(rentalOrders.holdExpiresAt, now)
        )
      );

    for (const order of cancelledOrders) {
      // Cancel order
      await db
        .update(rentalOrders)
        .set({
          status: "cancelled",
          cancelReason: "Hết thời gian thanh toán",
        })
        .where(eq(rentalOrders.id, order.id));

      // Release account if it was held by this order
      const account = await db
        .select()
        .from(ffAccounts)
        .where(eq(ffAccounts.id, order.accountId))
        .limit(1);

      if (account.length > 0 && account[0].currentOrderId === order.id) {
        await db
          .update(ffAccounts)
          .set({
            status: "available",
            currentRenterId: null,
            currentOrderId: null,
          })
          .where(eq(ffAccounts.id, order.accountId));
      }

      // Notify user
      await db.insert(notifications).values({
        userId: order.userId,
        title: "❌ Đơn hàng đã bị hủy",
        message: `Đơn hàng ${order.orderCode} đã bị hủy do hết thời gian thanh toán.`,
        type: "order",
        relatedId: order.id,
      });

      cancelledCount++;
    }

    // 3. Send 10-minute and 5-minute warnings
    const tenMinFromNow = new Date(now.getTime() + 10 * 60 * 1000);
    const fiveMinFromNow = new Date(now.getTime() + 5 * 60 * 1000);

    // 10-minute warning
    const tenMinOrders = await db
      .select()
      .from(rentalOrders)
      .where(
        and(
          eq(rentalOrders.status, "active"),
          sql`${rentalOrders.expiresAt} BETWEEN ${now} AND ${tenMinFromNow}`
        )
      );

    for (const order of tenMinOrders) {
      // Check if we already sent a warning (by checking notifications)
      // Simple approach: just send it
      await db.insert(notifications).values({
        userId: order.userId,
        title: "⚠️ Còn 10 phút",
        message: `Đơn hàng ${order.orderCode} - Thời gian thuê còn khoảng 10 phút. Gia hạn ngay nếu muốn tiếp tục!`,
        type: "order",
        relatedId: order.id,
      });
    }

    return NextResponse.json({
      success: true,
      data: {
        expiredOrders: expiredCount,
        cancelledOrders: cancelledCount,
        tenMinWarnings: tenMinOrders.length,
      },
    });
  } catch (error) {
    console.error("Cron expire error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống" },
      { status: 500 }
    );
  }
}
