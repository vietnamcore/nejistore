import { NextResponse } from "next/server";
import { db } from "@/db";
import { ffAccounts, pricing } from "@/db/schema";
import { eq, asc } from "drizzle-orm";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const account = await db
      .select()
      .from(ffAccounts)
      .where(eq(ffAccounts.id, id))
      .limit(1);

    if (account.length === 0) {
      return NextResponse.json(
        { success: false, error: "Không tìm thấy tài khoản" },
        { status: 404 }
      );
    }

    const accountPricing = await db
      .select()
      .from(pricing)
      .where(eq(pricing.accountId, id))
      .orderBy(asc(pricing.hours));

    const { gameEmail, gamePassword, ...safeAccount } = account[0];

    return NextResponse.json({
      success: true,
      data: {
        ...safeAccount,
        pricing: accountPricing,
      },
    });
  } catch (error) {
    console.error("Get account error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống" },
      { status: 500 }
    );
  }
}
