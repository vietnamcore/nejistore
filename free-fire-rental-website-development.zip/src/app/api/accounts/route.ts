import { NextResponse } from "next/server";
import { db } from "@/db";
import { ffAccounts, pricing } from "@/db/schema";
import { eq, asc } from "drizzle-orm";

export async function GET() {
  try {
    const accounts = await db
      .select()
      .from(ffAccounts)
      .where(eq(ffAccounts.isActive, true))
      .orderBy(asc(ffAccounts.sortOrder));

    const allPricing = await db
      .select()
      .from(pricing)
      .where(eq(pricing.isActive, true))
      .orderBy(asc(pricing.hours));

    const accountsWithPricing = accounts.map((account) => ({
      ...account,
      gameEmail: undefined,
      gamePassword: undefined,
      pricing: allPricing.filter((p) => p.accountId === account.id),
    }));

    return NextResponse.json({
      success: true,
      data: accountsWithPricing,
    });
  } catch (error) {
    console.error("Get accounts error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống" },
      { status: 500 }
    );
  }
}
