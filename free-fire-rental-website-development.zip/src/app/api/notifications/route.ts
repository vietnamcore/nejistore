import { NextResponse } from "next/server";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { getUserFromRequest } from "@/lib/auth";
import { eq, desc, and } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    const { user, error } = await getUserFromRequest(request);
    if (error || !user) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const userNotifications = await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, user.id))
      .orderBy(desc(notifications.createdAt));

    const unreadCount = userNotifications.filter((n) => !n.isRead).length;

    return NextResponse.json({
      success: true,
      data: userNotifications,
      unreadCount,
    });
  } catch (error) {
    console.error("Get notifications error:", error);
    return NextResponse.json({ success: false, error: "Lỗi hệ thống" }, { status: 500 });
  }
}

// Mark as read
export async function PUT(request: Request) {
  try {
    const { user, error } = await getUserFromRequest(request);
    if (error || !user) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { notificationId, markAllRead } = body;

    if (markAllRead) {
      await db
        .update(notifications)
        .set({ isRead: true })
        .where(and(eq(notifications.userId, user.id), eq(notifications.isRead, false)));
    } else if (notificationId) {
      await db
        .update(notifications)
        .set({ isRead: true })
        .where(and(eq(notifications.id, notificationId), eq(notifications.userId, user.id)));
    }

    return NextResponse.json({ success: true, message: "Đã cập nhật" });
  } catch (error) {
    console.error("Update notification error:", error);
    return NextResponse.json({ success: false, error: "Lỗi hệ thống" }, { status: 500 });
  }
}

// Delete notification
export async function DELETE(request: Request) {
  try {
    const { user, error } = await getUserFromRequest(request);
    if (error || !user) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const url = new URL(request.url);
    const notificationId = url.searchParams.get("id");
    const deleteAll = url.searchParams.get("all") === "true";

    if (deleteAll) {
      await db.delete(notifications).where(eq(notifications.userId, user.id));
    } else if (notificationId) {
      await db
        .delete(notifications)
        .where(and(eq(notifications.id, notificationId), eq(notifications.userId, user.id)));
    }

    return NextResponse.json({ success: true, message: "Đã xóa" });
  } catch (error) {
    console.error("Delete notification error:", error);
    return NextResponse.json({ success: false, error: "Lỗi hệ thống" }, { status: 500 });
  }
}
