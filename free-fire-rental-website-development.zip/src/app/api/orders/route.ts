import { NextResponse } from "next/server";
import { db } from "@/db";
import { rentalOrders, ffAccounts, pricing, notifications, auditLogs } from "@/db/schema";
import { createOrderSchema } from "@/lib/validations";
import { getUserFromRequest } from "@/lib/auth";
import { generateOrderCode, generateReceiveCode, getClientIp } from "@/lib/utils";
import { HOLD_DURATION_MINUTES } from "@/lib/constants";
import { eq, and, desc, sql } from "drizzle-orm";

// Create order
export async function POST(request: Request) {
  try {
    const { user, error: authError } = await getUserFromRequest(request);
    if (authError || !user) {
      return NextResponse.json(
        { success: false, error: "Vui lòng đăng nhập" },
        { status: 401 }
      );
    }

    if (!user.emailVerified) {
      return NextResponse.json(
        { success: false, error: "Vui lòng xác thực email trước khi thuê" },
        { status: 403 }
      );
    }

    const body = await request.json();
    const validated = createOrderSchema.safeParse(body);

    if (!validated.success) {
      return NextResponse.json(
        { success: false, error: validated.error.issues.map((i) => i.message).join(", ") },
        { status: 400 }
      );
    }

    const { accountId, hours, isExtension, parentOrderId } = validated.data;

    // Check if account exists and is available
    const account = await db
      .select()
      .from(ffAccounts)
      .where(eq(ffAccounts.id, accountId))
      .limit(1);

    if (account.length === 0) {
      return NextResponse.json(
        { success: false, error: "Tài khoản không tồn tại" },
        { status: 404 }
      );
    }

    const acc = account[0];

    if (!acc.isActive) {
      return NextResponse.json(
        { success: false, error: "Tài khoản không khả dụng" },
        { status: 400 }
      );
    }

    // For extensions, the account should be rented by this user
    if (isExtension) {
      if (acc.status !== "rented" || acc.currentRenterId !== user.id) {
        return NextResponse.json(
          { success: false, error: "Bạn không thể gia hạn tài khoản này" },
          { status: 400 }
        );
      }
    } else {
      // Check if account is available
      if (acc.status !== "available") {
        return NextResponse.json(
          { success: false, error: "Tài khoản hiện không sẵn sàng. Vui lòng chọn tài khoản khác." },
          { status: 400 }
        );
      }
    }

    // Check for existing pending orders for this account by this user
    const existingOrders = await db
      .select()
      .from(rentalOrders)
      .where(
        and(
          eq(rentalOrders.accountId, accountId),
          eq(rentalOrders.userId, user.id),
          sql`${rentalOrders.status} IN ('pending_payment', 'awaiting_confirmation', 'active')`
        )
      )
      .limit(1);

    if (existingOrders.length > 0 && !isExtension) {
      return NextResponse.json(
        { success: false, error: "Bạn đã có đơn thuê cho tài khoản này" },
        { status: 400 }
      );
    }

    // Get pricing for this account and hours
    const pricingEntry = await db
      .select()
      .from(pricing)
      .where(
        and(
          eq(pricing.accountId, accountId),
          eq(pricing.hours, hours),
          eq(pricing.isActive, true)
        )
      )
      .limit(1);

    if (pricingEntry.length === 0) {
      return NextResponse.json(
        { success: false, error: "Gói thuê không hợp lệ" },
        { status: 400 }
      );
    }

    const price = pricingEntry[0].price;

    // Use transaction to prevent race conditions
    const orderCode = generateOrderCode();
    const receiveCode = generateReceiveCode();
    const holdExpiresAt = new Date();
    holdExpiresAt.setMinutes(holdExpiresAt.getMinutes() + HOLD_DURATION_MINUTES);

    const paymentContent = `FFRENT ${orderCode}`;

    // Create order
    const [newOrder] = await db
      .insert(rentalOrders)
      .values({
        orderCode,
        receiveCode,
        userId: user.id,
        accountId,
        hours,
        price,
        status: "pending_payment",
        paymentStatus: "pending",
        paymentContent,
        holdExpiresAt,
        isExtension: isExtension || false,
        parentOrderId: parentOrderId || null,
      })
      .returning();

    // Update account status to pending_payment (only for new orders, not extensions)
    if (!isExtension) {
      await db
        .update(ffAccounts)
        .set({
          status: "pending_payment",
          currentRenterId: user.id,
          currentOrderId: newOrder.id,
        })
        .where(eq(ffAccounts.id, accountId));
    }

    // Create audit log
    const ip = getClientIp(request);
    const userAgent = request.headers.get("user-agent") || "unknown";
    await db.insert(auditLogs).values({
      userId: user.id,
      action: "order_created",
      entity: "rental_order",
      entityId: newOrder.id,
      details: JSON.stringify({ orderCode, accountId, hours, price }),
      ip,
      userAgent,
    });

    // Create notification
    await db.insert(notifications).values({
      userId: user.id,
      title: "🎮 Đặt thuê thành công",
      message: `Đơn hàng ${orderCode} đã được tạo. Vui lòng thanh toán trong ${HOLD_DURATION_MINUTES} phút.`,
      type: "order",
      relatedId: newOrder.id,
    });

    return NextResponse.json({
      success: true,
      data: {
        id: newOrder.id,
        orderCode: newOrder.orderCode,
        receiveCode: newOrder.receiveCode,
        accountId,
        accountName: acc.name,
        hours,
        price,
        status: newOrder.status,
        paymentContent: newOrder.paymentContent,
        holdExpiresAt: newOrder.holdExpiresAt,
        createdAt: newOrder.createdAt,
      },
      message: "Đặt thuê thành công! Vui lòng thanh toán trong 15 phút.",
    }, { status: 201 });
  } catch (error) {
    console.error("Create order error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống" },
      { status: 500 }
    );
  }
}

// Get user's orders
export async function GET(request: Request) {
  try {
    const { user, error: authError } = await getUserFromRequest(request);
    if (authError || !user) {
      return NextResponse.json(
        { success: false, error: "Vui lòng đăng nhập" },
        { status: 401 }
      );
    }

    const url = new URL(request.url);
    const status = url.searchParams.get("status");
    const search = url.searchParams.get("search");

    let query = db
      .select({
        order: rentalOrders,
        accountName: ffAccounts.name,
        accountImageUrl: ffAccounts.imageUrl,
      })
      .from(rentalOrders)
      .leftJoin(ffAccounts, eq(rentalOrders.accountId, ffAccounts.id))
      .where(eq(rentalOrders.userId, user.id))
      .orderBy(desc(rentalOrders.createdAt));

    if (status && status !== "all") {
      query = db
        .select({
          order: rentalOrders,
          accountName: ffAccounts.name,
          accountImageUrl: ffAccounts.imageUrl,
        })
        .from(rentalOrders)
        .leftJoin(ffAccounts, eq(rentalOrders.accountId, ffAccounts.id))
        .where(
          and(
            eq(rentalOrders.userId, user.id),
            eq(rentalOrders.status, status as "pending_payment" | "awaiting_confirmation" | "active" | "completed" | "expired" | "cancelled")
          )
        )
        .orderBy(desc(rentalOrders.createdAt));
    }

    const orders = await query;

    let filteredOrders = orders.map((o) => ({
      ...o.order,
      accountName: o.accountName,
      accountImageUrl: o.accountImageUrl,
    }));

    if (search) {
      const s = search.toLowerCase();
      filteredOrders = filteredOrders.filter(
        (o) =>
          o.orderCode.toLowerCase().includes(s) ||
          (o.accountName && o.accountName.toLowerCase().includes(s))
      );
    }

    return NextResponse.json({
      success: true,
      data: filteredOrders,
    });
  } catch (error) {
    console.error("Get orders error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống" },
      { status: 500 }
    );
  }
}
