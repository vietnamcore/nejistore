import { NextResponse } from "next/server";
import { db } from "@/db";
import { rentalOrders, ffAccounts, users, notifications, auditLogs } from "@/db/schema";
import { getUserFromRequest } from "@/lib/auth";
import { eq, and } from "drizzle-orm";
import { getClientIp } from "@/lib/utils";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { user, error: authError } = await getUserFromRequest(request);
    if (authError || !user) {
      return NextResponse.json(
        { success: false, error: "Vui lòng đăng nhập" },
        { status: 401 }
      );
    }

    const { id } = await params;

    const order = await db
      .select()
      .from(rentalOrders)
      .where(eq(rentalOrders.id, id))
      .limit(1);

    if (order.length === 0) {
      return NextResponse.json(
        { success: false, error: "Không tìm thấy đơn hàng" },
        { status: 404 }
      );
    }

    // Users can only see their own orders, admins can see all
    if (user.role !== "admin" && order[0].userId !== user.id) {
      return NextResponse.json(
        { success: false, error: "Không có quyền truy cập" },
        { status: 403 }
      );
    }

    const account = await db
      .select({ id: ffAccounts.id, name: ffAccounts.name, imageUrl: ffAccounts.imageUrl, status: ffAccounts.status })
      .from(ffAccounts)
      .where(eq(ffAccounts.id, order[0].accountId))
      .limit(1);

    const orderUser = await db
      .select({ id: users.id, username: users.username, fullName: users.fullName, email: users.email })
      .from(users)
      .where(eq(users.id, order[0].userId))
      .limit(1);

    return NextResponse.json({
      success: true,
      data: {
        ...order[0],
        account: account[0] || null,
        orderUser: user.role === "admin" ? orderUser[0] : undefined,
      },
    });
  } catch (error) {
    console.error("Get order error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống" },
      { status: 500 }
    );
  }
}

// Confirm payment by user
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { user, error: authError } = await getUserFromRequest(request);
    if (authError || !user) {
      return NextResponse.json(
        { success: false, error: "Vui lòng đăng nhập" },
        { status: 401 }
      );
    }

    const { id } = await params;

    const order = await db
      .select()
      .from(rentalOrders)
      .where(and(eq(rentalOrders.id, id), eq(rentalOrders.userId, user.id)))
      .limit(1);

    if (order.length === 0) {
      return NextResponse.json(
        { success: false, error: "Không tìm thấy đơn hàng" },
        { status: 404 }
      );
    }

    const o = order[0];

    if (o.status !== "pending_payment") {
      return NextResponse.json(
        { success: false, error: "Đơn hàng không ở trạng thái chờ thanh toán" },
        { status: 400 }
      );
    }

    // Check if hold period expired
    if (o.holdExpiresAt && o.holdExpiresAt < new Date()) {
      // Cancel order and release account
      await db
        .update(rentalOrders)
        .set({ status: "cancelled", cancelReason: "Hết thời gian thanh toán" })
        .where(eq(rentalOrders.id, id));

      // Release account
      await db
        .update(ffAccounts)
        .set({ status: "available", currentRenterId: null, currentOrderId: null })
        .where(eq(ffAccounts.id, o.accountId));

      return NextResponse.json(
        { success: false, error: "Đã hết thời gian thanh toán. Vui lòng đặt lại." },
        { status: 400 }
      );
    }

    // Update order status to awaiting confirmation
    await db
      .update(rentalOrders)
      .set({ status: "awaiting_confirmation" })
      .where(eq(rentalOrders.id, id));

    // Create audit log
    const ip = getClientIp(request);
    await db.insert(auditLogs).values({
      userId: user.id,
      action: "payment_confirmed_by_user",
      entity: "rental_order",
      entityId: id,
      ip,
    });

    // Notify admin
    const admins = await db
      .select()
      .from(users)
      .where(eq(users.role, "admin"));

    for (const admin of admins) {
      await db.insert(notifications).values({
        userId: admin.id,
        title: "💰 Khách đã thanh toán",
        message: `Đơn hàng ${o.orderCode} - Khách đã xác nhận thanh toán. Vui lòng kiểm tra và xác nhận.`,
        type: "payment",
        relatedId: id,
      });
    }

    // Notify user
    await db.insert(notifications).values({
      userId: user.id,
      title: "⏳ Đang chờ xác nhận",
      message: `Đơn hàng ${o.orderCode} - Admin đang kiểm tra thanh toán của bạn. Vui lòng đợi.`,
      type: "payment",
      relatedId: id,
    });

    return NextResponse.json({
      success: true,
      message: "Đã xác nhận thanh toán. Admin sẽ kiểm tra và xác nhận sớm.",
    });
  } catch (error) {
    console.error("Confirm payment error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống" },
      { status: 500 }
    );
  }
}
