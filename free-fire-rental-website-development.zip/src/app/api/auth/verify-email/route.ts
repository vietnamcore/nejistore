import { NextResponse } from "next/server";
import { db } from "@/db";
import { emailVerifications, users, auditLogs, notifications } from "@/db/schema";
import { eq, and, gt } from "drizzle-orm";
import { v4 as uuidv4 } from "uuid";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { token } = body;

    if (!token) {
      return NextResponse.json(
        { success: false, error: "Token không hợp lệ" },
        { status: 400 }
      );
    }

    // Find verification token
    const verification = await db
      .select()
      .from(emailVerifications)
      .where(and(eq(emailVerifications.token, token), eq(emailVerifications.used, false)))
      .limit(1);

    if (verification.length === 0) {
      return NextResponse.json(
        { success: false, error: "Token không hợp lệ hoặc đã được sử dụng" },
        { status: 400 }
      );
    }

    const ver = verification[0];

    // Check if expired
    if (ver.expiresAt < new Date()) {
      return NextResponse.json(
        { success: false, error: "Token đã hết hạn. Vui lòng yêu cầu gửi lại." },
        { status: 400 }
      );
    }

    // Mark token as used
    await db
      .update(emailVerifications)
      .set({ used: true })
      .where(eq(emailVerifications.id, ver.id));

    // Update user email verified
    await db
      .update(users)
      .set({
        emailVerified: true,
        emailVerifiedAt: new Date(),
      })
      .where(eq(users.id, ver.userId));

    // Create audit log
    await db.insert(auditLogs).values({
      userId: ver.userId,
      action: "email_verified",
      entity: "user",
      entityId: ver.userId,
    });

    // Create notification
    await db.insert(notifications).values({
      userId: ver.userId,
      title: "✅ Xác thực email thành công",
      message: "Email của bạn đã được xác thực. Bây giờ bạn có thể thuê tài khoản Free Fire!",
      type: "system",
    });

    return NextResponse.json({
      success: true,
      message: "Xác thực email thành công! Bạn có thể đăng nhập ngay.",
    });
  } catch (error) {
    console.error("Verify email error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống" },
      { status: 500 }
    );
  }
}

// Resend verification email
export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { email } = body;

    if (!email) {
      return NextResponse.json(
        { success: false, error: "Email không hợp lệ" },
        { status: 400 }
      );
    }

    const user = await db
      .select()
      .from(users)
      .where(eq(users.email, email))
      .limit(1);

    if (user.length === 0) {
      return NextResponse.json(
        { success: false, error: "Không tìm thấy tài khoản" },
        { status: 404 }
      );
    }

    if (user[0].emailVerified) {
      return NextResponse.json(
        { success: false, error: "Email đã được xác thực" },
        { status: 400 }
      );
    }

    // Create new verification token
    const verificationToken = uuidv4();
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24);

    await db.insert(emailVerifications).values({
      userId: user[0].id,
      token: verificationToken,
      expiresAt,
      used: false,
    });

    return NextResponse.json({
      success: true,
      message: "Đã gửi lại email xác thực",
      verificationToken: process.env.NODE_ENV === "development" ? verificationToken : undefined,
    });
  } catch (error) {
    console.error("Resend verification error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống" },
      { status: 500 }
    );
  }
}
