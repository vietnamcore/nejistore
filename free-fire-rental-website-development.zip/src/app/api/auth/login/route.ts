import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, sessions, loginAttempts, auditLogs, notifications } from "@/db/schema";
import { loginSchema } from "@/lib/validations";
import { verifyPassword, createSession, checkLoginAttempts, recordLoginAttempt, incrementFailedAttempts, resetFailedAttempts } from "@/lib/auth";
import { eq, or } from "drizzle-orm";
import { sendEmail, loginAlertTemplate } from "@/lib/email";
import { APP_URL } from "@/lib/constants";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const validated = loginSchema.safeParse(body);

    if (!validated.success) {
      const errors = validated.error.issues.map((i) => i.message).join(", ");
      return NextResponse.json({ success: false, error: errors }, { status: 400 });
    }

    const { login, password, remember } = validated.data;
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
    const userAgent = request.headers.get("user-agent") || "unknown";

    // Check login attempts
    const { allowed, lockedUntil } = await checkLoginAttempts(login);
    if (!allowed) {
      return NextResponse.json(
        {
          success: false,
          error: `Tài khoản đã bị khóa do đăng nhập sai quá nhiều. Vui lòng thử lại sau ${lockedUntil ? new Date(lockedUntil).toLocaleTimeString("vi-VN") : "15 phút"}.`,
        },
        { status: 429 }
      );
    }

    // Find user by email or username
    const foundUsers = await db
      .select()
      .from(users)
      .where(or(eq(users.email, login), eq(users.username, login)))
      .limit(1);

    if (foundUsers.length === 0) {
      await recordLoginAttempt(login, ip, false);
      return NextResponse.json(
        { success: false, error: "Email/Username hoặc mật khẩu không đúng" },
        { status: 401 }
      );
    }

    const user = foundUsers[0];

    // Check if account is active
    if (!user.isActive) {
      return NextResponse.json(
        { success: false, error: "Tài khoản đã bị vô hiệu hóa" },
        { status: 403 }
      );
    }

    // Check if account is locked
    if (user.lockedUntil && new Date() < user.lockedUntil) {
      return NextResponse.json(
        {
          success: false,
          error: `Tài khoản đã bị khóa do đăng nhập sai quá nhiều. Vui lòng thử lại sau ${new Date(user.lockedUntil).toLocaleTimeString("vi-VN")}.`,
        },
        { status: 429 }
      );
    }

    // Check if email is verified
    if (!user.emailVerified) {
      return NextResponse.json(
        { success: false, error: "Vui lòng xác thực email trước khi đăng nhập", needVerification: true, email: user.email },
        { status: 403 }
      );
    }

    // Verify password
    const isValid = await verifyPassword(password, user.password);
    if (!isValid) {
      await recordLoginAttempt(login, ip, false);
      await incrementFailedAttempts(user.id);

      // Create audit log
      await db.insert(auditLogs).values({
        userId: user.id,
        action: "login_failed",
        entity: "user",
        entityId: user.id,
        ip,
        userAgent,
      });

      // Check if we should send warning
      if (user.failedLoginAttempts + 1 >= 5) {
        await db.insert(notifications).values({
          userId: user.id,
          title: "⚠️ Cảnh báo đăng nhập",
          message: "Tài khoản của bạn có nhiều lần đăng nhập sai. Nếu không phải bạn, hãy đổi mật khẩu ngay.",
          type: "security",
        });
      }

      return NextResponse.json(
        { success: false, error: "Email/Username hoặc mật khẩu không đúng" },
        { status: 401 }
      );
    }

    // Reset failed attempts
    await resetFailedAttempts(user.id);
    await recordLoginAttempt(login, ip, true);

    // Create session
    const { token } = await createSession(user.id, ip, userAgent);

    // Create audit log
    await db.insert(auditLogs).values({
      userId: user.id,
      action: "login_success",
      entity: "user",
      entityId: user.id,
      ip,
      userAgent,
    });

    // Send login alert if new device
    if (user.lastLoginIp && user.lastLoginIp !== ip) {
      await sendEmail({
        to: user.email,
        subject: "FF Rent - Đăng nhập từ thiết bị mới",
        html: loginAlertTemplate(ip, userAgent),
      });
    }

    // Update last login
    await db
      .update(users)
      .set({ lastLoginAt: new Date(), lastLoginIp: ip })
      .where(eq(users.id, user.id));

    const response = NextResponse.json({
      success: true,
      data: {
        user: {
          id: user.id,
          email: user.email,
          username: user.username,
          fullName: user.fullName,
          phone: user.phone,
          avatar: user.avatar,
          role: user.role,
          emailVerified: user.emailVerified,
          createdAt: user.createdAt,
        },
        token,
      },
      message: "Đăng nhập thành công",
    });

    response.cookies.set("auth_token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: remember ? 60 * 60 * 24 * 30 : 60 * 60 * 24 * 7,
      path: "/",
    });

    return response;
  } catch (error) {
    console.error("Login error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống. Vui lòng thử lại." },
      { status: 500 }
    );
  }
}
