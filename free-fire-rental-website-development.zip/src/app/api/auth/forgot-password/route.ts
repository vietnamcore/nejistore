import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, passwordResets, auditLogs } from "@/db/schema";
import { forgotPasswordSchema } from "@/lib/validations";
import { eq } from "drizzle-orm";
import { v4 as uuidv4 } from "uuid";
import { sendEmail, passwordResetTemplate } from "@/lib/email";
import { APP_URL } from "@/lib/constants";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const validated = forgotPasswordSchema.safeParse(body);

    if (!validated.success) {
      return NextResponse.json(
        { success: false, error: validated.error.issues.map((i) => i.message).join(", ") },
        { status: 400 }
      );
    }

    const { email } = validated.data;

    const user = await db
      .select()
      .from(users)
      .where(eq(users.email, email))
      .limit(1);

    // Always return success to prevent email enumeration
    if (user.length === 0) {
      return NextResponse.json({
        success: true,
        message: "Nếu email tồn tại, bạn sẽ nhận được liên kết đặt lại mật khẩu.",
      });
    }

    // Create reset token
    const resetToken = uuidv4();
    const expiresAt = new Date();
    expiresAt.setMinutes(expiresAt.getMinutes() + 15);

    await db.insert(passwordResets).values({
      userId: user[0].id,
      token: resetToken,
      expiresAt,
      used: false,
    });

    // Send email
    await sendEmail({
      to: email,
      subject: "FF Rent - Đặt lại mật khẩu",
      html: passwordResetTemplate(resetToken, APP_URL),
    });

    // Create audit log
    await db.insert(auditLogs).values({
      userId: user[0].id,
      action: "forgot_password_requested",
      entity: "user",
      entityId: user[0].id,
    });

    return NextResponse.json({
      success: true,
      message: "Nếu email tồn tại, bạn sẽ nhận được liên kết đặt lại mật khẩu.",
      resetToken: process.env.NODE_ENV === "development" ? resetToken : undefined,
    });
  } catch (error) {
    console.error("Forgot password error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống" },
      { status: 500 }
    );
  }
}
