import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, passwordResets, auditLogs, sessions, notifications } from "@/db/schema";
import { resetPasswordSchema } from "@/lib/validations";
import { hashPassword, deleteAllUserSessions } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const validated = resetPasswordSchema.safeParse(body);

    if (!validated.success) {
      return NextResponse.json(
        { success: false, error: validated.error.issues.map((i) => i.message).join(", ") },
        { status: 400 }
      );
    }

    const { token, password } = validated.data;

    // Find reset token
    const reset = await db
      .select()
      .from(passwordResets)
      .where(eq(passwordResets.token, token))
      .limit(1);

    if (reset.length === 0) {
      return NextResponse.json(
        { success: false, error: "Token không hợp lệ" },
        { status: 400 }
      );
    }

    const resetEntry = reset[0];

    if (resetEntry.used) {
      return NextResponse.json(
        { success: false, error: "Token đã được sử dụng" },
        { status: 400 }
      );
    }

    if (resetEntry.expiresAt < new Date()) {
      return NextResponse.json(
        { success: false, error: "Token đã hết hạn" },
        { status: 400 }
      );
    }

    // Hash new password
    const hashedPassword = await hashPassword(password);

    // Update password
    await db
      .update(users)
      .set({ password: hashedPassword })
      .where(eq(users.id, resetEntry.userId));

    // Mark token as used
    await db
      .update(passwordResets)
      .set({ used: true })
      .where(eq(passwordResets.id, resetEntry.id));

    // Delete all sessions (force re-login)
    await db.delete(sessions).where(eq(sessions.userId, resetEntry.userId));

    // Create audit log
    await db.insert(auditLogs).values({
      userId: resetEntry.userId,
      action: "password_reset",
      entity: "user",
      entityId: resetEntry.userId,
    });

    // Create notification
    await db.insert(notifications).values({
      userId: resetEntry.userId,
      title: "🔒 Mật khẩu đã được thay đổi",
      message: "Mật khẩu của bạn đã được đặt lại thành công. Bạn đã được đăng xuất khỏi tất cả thiết bị.",
      type: "security",
    });

    return NextResponse.json({
      success: true,
      message: "Đặt lại mật khẩu thành công. Vui lòng đăng nhập lại.",
    });
  } catch (error) {
    console.error("Reset password error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống" },
      { status: 500 }
    );
  }
}
