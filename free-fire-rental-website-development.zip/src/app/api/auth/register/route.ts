import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, emailVerifications, auditLogs } from "@/db/schema";
import { registerSchema } from "@/lib/validations";
import { hashPassword, createSession } from "@/lib/auth";
import { generateOrderCode } from "@/lib/utils";
import { eq } from "drizzle-orm";
import { v4 as uuidv4 } from "uuid";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const validated = registerSchema.safeParse(body);

    if (!validated.success) {
      const errors = validated.error.issues.map((i) => i.message).join(", ");
      return NextResponse.json({ success: false, error: errors }, { status: 400 });
    }

    const { fullName, username, email, phone, password } = validated.data;

    // Check if email already exists
    const existingEmail = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.email, email))
      .limit(1);

    if (existingEmail.length > 0) {
      return NextResponse.json(
        { success: false, error: "Email đã được sử dụng" },
        { status: 409 }
      );
    }

    // Check if username already exists
    const existingUsername = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.username, username))
      .limit(1);

    if (existingUsername.length > 0) {
      return NextResponse.json(
        { success: false, error: "Username đã được sử dụng" },
        { status: 409 }
      );
    }

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Create user
    const [newUser] = await db
      .insert(users)
      .values({
        email,
        username,
        fullName,
        phone,
        password: hashedPassword,
        role: "user",
        emailVerified: false,
        isActive: true,
      })
      .returning();

    // Create email verification token
    const verificationToken = uuidv4();
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24);

    await db.insert(emailVerifications).values({
      userId: newUser.id,
      token: verificationToken,
      expiresAt,
      used: false,
    });

    // Create session
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
    const userAgent = request.headers.get("user-agent") || "unknown";
    const { token } = await createSession(newUser.id, ip, userAgent);

    // Create audit log
    await db.insert(auditLogs).values({
      userId: newUser.id,
      action: "register",
      entity: "user",
      entityId: newUser.id,
      ip,
      userAgent,
    });

    // Create notification
    const { notifications } = await import("@/db/schema");
    await db.insert(notifications).values({
      userId: newUser.id,
      title: "Chào mừng bạn đến với FF Rent! 🎮",
      message: "Tài khoản của bạn đã được tạo thành công. Vui lòng xác thực email để bắt đầu thuê tài khoản Free Fire.",
      type: "system",
    });

    // Set cookie
    const response = NextResponse.json(
      {
        success: true,
        data: {
          user: {
            id: newUser.id,
            email: newUser.email,
            username: newUser.username,
            fullName: newUser.fullName,
            role: newUser.role,
            emailVerified: newUser.emailVerified,
          },
          token,
          verificationToken: process.env.NODE_ENV === "development" ? verificationToken : undefined,
        },
        message: "Đăng ký thành công! Vui lòng kiểm tra email để xác thực tài khoản.",
      },
      { status: 201 }
    );

    response.cookies.set("auth_token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
      path: "/",
    });

    return response;
  } catch (error) {
    console.error("Register error:", error);
    return NextResponse.json(
      { success: false, error: "Lỗi hệ thống. Vui lòng thử lại." },
      { status: 500 }
    );
  }
}
