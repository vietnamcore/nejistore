"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { motion, useInView, useScroll, useTransform } from "framer-motion";
import {
  Gamepad2,
  Clock,
  Shield,
  Zap,
  ChevronRight,
  Star,
  Check,
  ArrowRight,
  Play,
  Users,
  TrendingUp,
  Award,
  HelpCircle,
  Phone,
  MessageCircle,
  Mail,
} from "lucide-react";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import {
  FAQ_ITEMS,
  TESTIMONIALS,
  SUPPORT_PHONE,
  SUPPORT_ZALO,
  SUPPORT_EMAIL,
} from "@/lib/constants";
import { formatCurrency } from "@/lib/utils";

// ==================== ANIMATION VARIANTS ====================

const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" as const } },
};

const fadeIn = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.5 } },
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
};

// ==================== HERO SECTION ====================

function HeroSection() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [0, 100]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  return (
    <section ref={ref} className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-[#0a1a0a] to-black" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-primary/3 rounded-full blur-[120px]" />
        {/* Particles */}
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="particle"
            style={{
              left: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 8}s`,
              animationDuration: `${6 + Math.random() * 6}s`,
            }}
          />
        ))}
      </div>

      <motion.div style={{ y, opacity }} className="relative z-10 max-w-5xl mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass text-sm text-primary mb-8"
          >
            <Zap className="w-4 h-4" />
            Cho thuê theo giờ - Bắt đầu từ 20.000đ
          </motion.div>

          <h1 className="hero-title font-black leading-tight mb-6">
            <span className="text-white">Thuê Tài Khoản</span>
            <br />
            <span className="bg-gradient-to-r from-primary via-primary-light to-primary bg-clip-text text-transparent">
              Free Fire
            </span>
            <br />
            <span className="text-white">Theo Giờ</span>
          </h1>

          <p className="text-lg sm:text-xl text-neutral-400 max-w-2xl mx-auto mb-10 leading-relaxed">
            Trải nghiệm tài khoản Free Fire xịn nhất với giá chỉ từ{" "}
            <span className="text-primary font-semibold">20.000đ/giờ</span>.
            Uy tín, nhanh chóng, an toàn.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/accounts">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="btn-shine px-8 py-4 bg-gradient-to-r from-primary to-primary-dark text-white font-semibold rounded-xl shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-all flex items-center gap-2"
              >
                <Play className="w-5 h-5" />
                Thuê Ngay
              </motion.button>
            </Link>
            <Link href="/pricing">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 glass text-white font-semibold rounded-xl hover:bg-white/10 transition-all flex items-center gap-2"
              >
                Xem Bảng Giá
                <ChevronRight className="w-5 h-5" />
              </motion.button>
            </Link>
          </div>
        </motion.div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-6 h-10 rounded-full border-2 border-neutral-700 flex items-start justify-center p-1.5"
        >
          <div className="w-1.5 h-2.5 rounded-full bg-primary" />
        </motion.div>
      </motion.div>
    </section>
  );
}

// ==================== STATS SECTION ====================

function StatsSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const stats = [
    { icon: Users, value: "500+", label: "Khách hàng" },
    { icon: Gamepad2, value: "6", label: "Tài khoản" },
    { icon: Clock, value: "24/7", label: "Hỗ trợ" },
    { icon: Award, value: "99%", label: "Hài lòng" },
  ];

  return (
    <section ref={ref} className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid grid-cols-2 md:grid-cols-4 gap-6"
        >
          {stats.map((stat, i) => (
            <motion.div
              key={i}
              variants={fadeInUp}
              className="glass rounded-2xl p-6 text-center hover:glow-green transition-all duration-300"
            >
              <stat.icon className="w-8 h-8 text-primary mx-auto mb-3" />
              <p className="text-2xl sm:text-3xl font-bold text-white counter-value">{stat.value}</p>
              <p className="text-sm text-neutral-500 mt-1">{stat.label}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

// ==================== ACCOUNTS PREVIEW ====================

function AccountsPreview() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const accounts = [
    { name: "Acc 1 - Diamond", price: "30.000đ", hours: "1 giờ", rank: "Heroic", status: "available" },
    { name: "Acc 2 - Elite", price: "35.000đ", hours: "1 giờ", rank: "Grandmaster", status: "available" },
    { name: "Acc 3 - Premium", price: "30.000đ", hours: "1 giờ", rank: "Heroic", status: "rented" },
    { name: "Acc 4 - Standard", price: "25.000đ", hours: "1 giờ", rank: "Diamond", status: "available" },
    { name: "Acc 5 - Classic", price: "30.000đ", hours: "1 giờ", rank: "Heroic", status: "available" },
    { name: "Acc 6 - Starter", price: "20.000đ", hours: "1 giờ", rank: "Gold", status: "available" },
  ];

  return (
    <section ref={ref} className="py-20 relative" id="accounts">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-12"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Tài Khoản <span className="text-primary">Free Fire</span>
          </h2>
          <p className="text-neutral-400 max-w-2xl mx-auto">
            Chọn tài khoản phù hợp với bạn. Mỗi tài khoản chỉ cho 01 người thuê tại một thời điểm.
          </p>
        </motion.div>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {accounts.map((acc, i) => (
            <motion.div
              key={i}
              variants={fadeInUp}
              whileHover={{ y: -5, scale: 1.02 }}
              className="glass rounded-2xl p-6 hover:glow-green transition-all duration-300 group"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                    <Gamepad2 className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white text-sm">{acc.name}</h3>
                    <p className="text-xs text-neutral-500">Rank: {acc.rank}</p>
                  </div>
                </div>
                <span
                  className={`px-2 py-1 rounded-full text-xs font-medium ${
                    acc.status === "available"
                      ? "bg-green-400/10 text-green-400 border border-green-400/20"
                      : "bg-red-400/10 text-red-400 border border-red-400/20"
                  }`}
                >
                  {acc.status === "available" ? "Có sẵn" : "Đang thuê"}
                </span>
              </div>

              <div className="flex items-end justify-between">
                <div>
                  <p className="text-xs text-neutral-500">Từ</p>
                  <p className="text-xl font-bold text-primary">{acc.price}</p>
                  <p className="text-xs text-neutral-500">/ {acc.hours}</p>
                </div>
                <Link href="/accounts">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    disabled={acc.status !== "available"}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                      acc.status === "available"
                        ? "bg-primary/10 text-primary hover:bg-primary/20"
                        : "bg-neutral-800 text-neutral-600 cursor-not-allowed"
                    }`}
                  >
                    Thuê ngay
                  </motion.button>
                </Link>
              </div>
            </motion.div>
          ))}
        </motion.div>

        <div className="text-center mt-10">
          <Link href="/accounts">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-6 py-3 glass rounded-xl text-primary font-medium hover:bg-white/5 transition-all inline-flex items-center gap-2"
            >
              Xem tất cả tài khoản
              <ArrowRight className="w-4 h-4" />
            </motion.button>
          </Link>
        </div>
      </div>
    </section>
  );
}

// ==================== PROCESS SECTION ====================

function ProcessSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const steps = [
    { icon: Users, title: "Đăng ký", desc: "Tạo tài khoản và xác thực email" },
    { icon: Gamepad2, title: "Chọn Acc", desc: "Chọn tài khoản và số giờ thuê" },
    { icon: Shield, title: "Thanh toán", desc: "Chuyển khoản theo hướng dẫn" },
    { icon: Zap, title: "Nhận Acc", desc: "Admin xác nhận và cấp tài khoản" },
  ];

  return (
    <section ref={ref} className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-12"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Quy Trình <span className="text-primary">Thuê</span>
          </h2>
          <p className="text-neutral-400">Chỉ 4 bước đơn giản để bắt đầu chơi</p>
        </motion.div>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {steps.map((step, i) => (
            <motion.div
              key={i}
              variants={fadeInUp}
              className="relative glass rounded-2xl p-6 text-center"
            >
              <div className="absolute -top-3 -left-3 w-8 h-8 rounded-full bg-primary text-white text-sm font-bold flex items-center justify-center">
                {i + 1}
              </div>
              <step.icon className="w-10 h-10 text-primary mx-auto mb-4" />
              <h3 className="font-semibold text-white mb-2">{step.title}</h3>
              <p className="text-sm text-neutral-500">{step.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

// ==================== FEATURES SECTION ====================

function FeaturesSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const features = [
    { icon: Shield, title: "An toàn tuyệt đối", desc: "Thông tin được bảo mật, không chia sẻ tài khoản" },
    { icon: Clock, title: "Tính giờ chính xác", desc: "Đếm ngược từng giây, tự động hết hạn" },
    { icon: Zap, title: "Nhanh chóng", desc: "Xác nhận thanh toán trong vài phút" },
    { icon: TrendingUp, title: "Gia hạn dễ dàng", desc: "Gia hạn thêm giờ khi đang thuê" },
    { icon: Users, title: "Không trùng lặp", desc: "Mỗi acc chỉ 01 người thuê cùng lúc" },
    { icon: Award, title: "Uy tín hàng đầu", desc: "Hàng trăm khách hàng hài lòng" },
  ];

  return (
    <section ref={ref} className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-12"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Tại Sao Chọn <span className="text-primary">FF Rent?</span>
          </h2>
        </motion.div>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {features.map((feature, i) => (
            <motion.div
              key={i}
              variants={fadeInUp}
              whileHover={{ y: -3 }}
              className="glass rounded-2xl p-6 flex items-start gap-4 hover:glow-green transition-all duration-300"
            >
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <feature.icon className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-white mb-1">{feature.title}</h3>
                <p className="text-sm text-neutral-500">{feature.desc}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

// ==================== TESTIMONIALS SECTION ====================

function TestimonialsSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-12"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Khách Hàng <span className="text-primary">Nói Gì?</span>
          </h2>
        </motion.div>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {TESTIMONIALS.map((t, i) => (
            <motion.div
              key={i}
              variants={fadeInUp}
              whileHover={{ y: -3 }}
              className="glass rounded-2xl p-6"
            >
              <div className="flex items-center gap-1 mb-3">
                {Array.from({ length: t.rating }).map((_, j) => (
                  <Star key={j} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="text-sm text-neutral-400 mb-4 leading-relaxed">&ldquo;{t.content}&rdquo;</p>
              <p className="text-sm font-medium text-white">{t.name}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

// ==================== FAQ SECTION ====================

function FAQSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section ref={ref} className="py-20 relative" id="faq">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-12"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Câu Hỏi <span className="text-primary">Thường Gặp</span>
          </h2>
        </motion.div>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="space-y-3"
        >
          {FAQ_ITEMS.map((faq, i) => (
            <motion.div key={i} variants={fadeInUp} className="glass rounded-xl overflow-hidden">
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full flex items-center justify-between p-4 text-left"
              >
                <span className="font-medium text-white text-sm pr-4">{faq.question}</span>
                <HelpCircle
                  className={`w-5 h-5 text-primary shrink-0 transition-transform duration-200 ${
                    openIndex === i ? "rotate-180" : ""
                  }`}
                />
              </button>
              <motion.div
                initial={false}
                animate={{
                  height: openIndex === i ? "auto" : 0,
                  opacity: openIndex === i ? 1 : 0,
                }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden"
              >
                <p className="px-4 pb-4 text-sm text-neutral-400 leading-relaxed">{faq.answer}</p>
              </motion.div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

// ==================== CONTACT SECTION ====================

function ContactSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-20 relative" id="contact">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-12"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Cần <span className="text-primary">Hỗ Trợ?</span>
          </h2>
          <p className="text-neutral-400">Liên hệ với chúng tôi bất cứ lúc nào</p>
        </motion.div>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid grid-cols-1 sm:grid-cols-3 gap-6"
        >
          <motion.a
            variants={fadeInUp}
            href={`tel:${SUPPORT_PHONE}`}
            className="glass rounded-2xl p-6 text-center hover:glow-green transition-all duration-300 group"
          >
            <Phone className="w-8 h-8 text-primary mx-auto mb-3 group-hover:scale-110 transition-transform" />
            <h3 className="font-semibold text-white mb-1">Gọi điện</h3>
            <p className="text-sm text-neutral-400">{SUPPORT_PHONE}</p>
          </motion.a>
          <motion.a
            variants={fadeInUp}
            href={SUPPORT_ZALO}
            target="_blank"
            className="glass rounded-2xl p-6 text-center hover:glow-green transition-all duration-300 group"
          >
            <MessageCircle className="w-8 h-8 text-primary mx-auto mb-3 group-hover:scale-110 transition-transform" />
            <h3 className="font-semibold text-white mb-1">Zalo</h3>
            <p className="text-sm text-neutral-400">Nhắn tin qua Zalo</p>
          </motion.a>
          <motion.a
            variants={fadeInUp}
            href={`mailto:${SUPPORT_EMAIL}`}
            className="glass rounded-2xl p-6 text-center hover:glow-green transition-all duration-300 group"
          >
            <Mail className="w-8 h-8 text-primary mx-auto mb-3 group-hover:scale-110 transition-transform" />
            <h3 className="font-semibold text-white mb-1">Email</h3>
            <p className="text-sm text-neutral-400">{SUPPORT_EMAIL}</p>
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
}

// ==================== MAIN PAGE ====================

export default function HomePage() {
  return (
    <main id="main-content" className="aurora-bg">
      <Header />
      <HeroSection />
      <StatsSection />
      <AccountsPreview />
      <ProcessSection />
      <FeaturesSection />
      <TestimonialsSection />
      <FAQSection />
      <ContactSection />
      <Footer />
    </main>
  );
}
