"use client";

import { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { motion } from "framer-motion";
import { CheckCircle, XCircle, Loader2 } from "lucide-react";
import Link from "next/link";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

export default function VerifyEmailPage() {
  return (
    <Suspense fallback={
      <main className="aurora-bg min-h-screen">
        <Header />
        <div className="flex items-center justify-center min-h-screen pt-20 px-4">
          <Loader2 className="w-16 h-16 text-primary animate-spin" />
        </div>
        <Footer />
      </main>
    }>
      <VerifyEmailContent />
    </Suspense>
  );
}

function VerifyEmailContent() {
  const searchParams = useSearchParams();
  const token = searchParams.get("token");
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading");
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (token) {
      verifyEmail(token);
    } else {
      setStatus("error");
      setMessage("Token không hợp lệ");
    }
  }, [token]);

  const verifyEmail = async (t: string) => {
    try {
      const res = await fetch("/api/auth/verify-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: t }),
      });
      const data = await res.json();
      if (data.success) {
        setStatus("success");
        setMessage(data.message);
      } else {
        setStatus("error");
        setMessage(data.error);
      }
    } catch {
      setStatus("error");
      setMessage("Lỗi kết nối");
    }
  };

  return (
    <main className="aurora-bg min-h-screen">
      <Header />
      <div className="flex items-center justify-center min-h-screen pt-20 px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md glass-strong rounded-2xl p-8 text-center"
        >
          {status === "loading" && (
            <>
              <Loader2 className="w-16 h-16 text-primary mx-auto mb-4 animate-spin" />
              <h1 className="text-xl font-bold text-white mb-2">Đang xác thực...</h1>
            </>
          )}
          {status === "success" && (
            <>
              <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
              <h1 className="text-xl font-bold text-white mb-2">Xác thực thành công!</h1>
              <p className="text-neutral-400 mb-6">{message}</p>
              <Link href="/login" className="text-primary hover:text-primary-light">
                Đăng nhập ngay →
              </Link>
            </>
          )}
          {status === "error" && (
            <>
              <XCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
              <h1 className="text-xl font-bold text-white mb-2">Xác thực thất bại</h1>
              <p className="text-neutral-400 mb-6">{message}</p>
              <Link href="/login" className="text-primary hover:text-primary-light">
                Quay lại đăng nhập
              </Link>
            </>
          )}
        </motion.div>
      </div>
      <Footer />
    </main>
  );
}
