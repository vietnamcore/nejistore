"use client";

import { motion } from "framer-motion";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

export default function PrivacyPage() {
  return (
    <main className="aurora-bg min-h-screen">
      <Header />
      <div className="max-w-3xl mx-auto px-4 sm:px-6 pt-28 pb-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">Chính Sách Bảo Mật</h1>
          <p className="text-neutral-500 text-sm mb-8">Cập nhật lần cuối: {new Date().toLocaleDateString("vi-VN")}</p>

          <div className="glass-strong rounded-2xl p-8">
            <div className="space-y-6 text-neutral-300 text-sm leading-relaxed">
              <section>
                <h2 className="text-lg font-semibold text-white mb-3">1. Thu thập thông tin</h2>
                <p>Chúng tôi thu thập các thông tin cần thiết để cung cấp dịch vụ: họ tên, email, số điện thoại, username. Mật khẩu được mã hóa bằng bcrypt và không lưu dưới dạng văn bản.</p>
              </section>

              <section>
                <h2 className="text-lg font-semibold text-white mb-3">2. Sử dụng thông tin</h2>
                <p>Thông tin của bạn chỉ được sử dụng để: cung cấp dịch vụ, liên hệ hỗ trợ, gửi thông báo, xử lý thanh toán.</p>
              </section>

              <section>
                <h2 className="text-lg font-semibold text-white mb-3">3. Bảo mật</h2>
                <p>Chúng tôi sử dụng các biện pháp bảo mật: mã hóa mật khẩu, JWT, HTTPS, CSRF protection, XSS protection, SQL injection protection.</p>
              </section>

              <section>
                <h2 className="text-lg font-semibold text-white mb-3">4. Chia sẻ thông tin</h2>
                <p>Chúng tôi không chia sẻ thông tin cá nhân của bạn cho bên thứ ba, trừ khi có yêu cầu từ cơ quan pháp luật.</p>
              </section>

              <section>
                <h2 className="text-lg font-semibold text-white mb-3">5. Quyền của bạn</h2>
                <p>Bạn có quyền: xem thông tin cá nhân, chỉnh sửa thông tin, yêu cầu xóa tài khoản, từ chối nhận thông báo.</p>
              </section>

              <section>
                <h2 className="text-lg font-semibold text-white mb-3">6. Cookie</h2>
                <p>Chúng tôi sử dụng cookie để: duy trì phiên đăng nhập, lưu trữ tùy chọn giao diện, cải thiện trải nghiệm người dùng.</p>
              </section>

              <section>
                <h2 className="text-lg font-semibold text-white mb-3">7. Liên hệ</h2>
                <p>Nếu bạn có thắc mắc về chính sách bảo mật, vui lòng liên hệ qua email hoặc Zalo hỗ trợ.</p>
              </section>
            </div>
          </div>
        </motion.div>
      </div>
      <Footer />
    </main>
  );
}
