"use client";

import { motion } from "framer-motion";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

export default function TermsPage() {
  return (
    <main className="aurora-bg min-h-screen">
      <Header />
      <div className="max-w-3xl mx-auto px-4 sm:px-6 pt-28 pb-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">Điều Khoản Sử Dụng</h1>
          <p className="text-neutral-500 text-sm mb-8">Cập nhật lần cuối: {new Date().toLocaleDateString("vi-VN")}</p>

          <div className="glass-strong rounded-2xl p-8 prose prose-invert max-w-none">
            <div className="space-y-6 text-neutral-300 text-sm leading-relaxed">
              <section>
                <h2 className="text-lg font-semibold text-white mb-3">1. Tổng quan</h2>
                <p>Bằng việc sử dụng dịch vụ FF Rent, bạn đồng ý với các điều khoản sau. Vui lòng đọc kỹ trước khi sử dụng.</p>
              </section>

              <section>
                <h2 className="text-lg font-semibold text-white mb-3">2. Dịch vụ</h2>
                <p>FF Rent cung cấp dịch vụ cho thuê tài khoản Free Fire theo giờ. Tài khoản chỉ được sử dụng bởi một người tại một thời điểm.</p>
              </section>

              <section>
                <h2 className="text-lg font-semibold text-white mb-3">3. Thanh toán</h2>
                <p>Thanh toán được thực hiện qua chuyển khoản ngân hàng. Sau khi chuyển khoản, Admin sẽ xác nhận thủ công. Thời gian xác nhận có thể từ vài phút đến vài giờ.</p>
              </section>

              <section>
                <h2 className="text-lg font-semibold text-white mb-3">4. Quy định sử dụng</h2>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Không thay đổi thông tin tài khoản (email, mật khẩu, liên kết)</li>
                  <li>Không chia sẻ tài khoản cho người khác</li>
                  <li>Không sử dụng cheat, hack hoặc phần mềm gian lận</li>
                  <li>Không vi phạm điều khoản của Garena Free Fire</li>
                  <li>Không xóa bạn bè, đồ vật hoặc thay đổi cài đặt tài khoản</li>
                </ul>
              </section>

              <section>
                <h2 className="text-lg font-semibold text-white mb-3">5. Hoàn tiền</h2>
                <p>Hoàn tiền chỉ được thực hiện khi tài khoản không thể sử dụng do lỗi từ phía chúng tôi. Yêu cầu hoàn tiền phải được gửi trong vòng 30 phút sau khi thuê.</p>
              </section>

              <section>
                <h2 className="text-lg font-semibold text-white mb-3">6. Trách nhiệm</h2>
                <p>Chúng tôi không chịu trách nhiệm về bất kỳ vi phạm nào do người dùng tự ý gây ra. Nếu tài khoản bị khóa do vi phạm của người dùng, không hoàn tiền.</p>
              </section>

              <section>
                <h2 className="text-lg font-semibold text-white mb-3">7. Liên hệ</h2>
                <p>Mọi thắc mắc vui lòng liên hệ qua Zalo hoặc số điện thoại hỗ trợ.</p>
              </section>
            </div>
          </div>
        </motion.div>
      </div>
      <Footer />
    </main>
  );
}
