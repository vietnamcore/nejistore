import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { v4 as uuidv4 } from "uuid";
import { db } from "@/db";
import { users, sessions, loginAttempts } from "@/db/schema";
import { eq, and, gt, sql } from "drizzle-orm";

const JWT_SECRET = process.env.JWT_SECRET || "ff-rental-secret-key-change-in-production";
const JWT_EXPIRES_IN = "7d";
const SALT_ROUNDS = 12;
const MAX_LOGIN_ATTEMPTS = 5;
const LOCK_DURATION_MINUTES = 15;

export interface JWTPayload {
  userId: string;
  email: string;
  role: "user" | "admin";
  sessionId: string;
}

// ==================== PASSWORD ====================

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

// ==================== JWT ====================

export function generateToken(payload: JWTPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
}

export function verifyToken(token: string): JWTPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as JWTPayload;
  } catch {
    return null;
  }
}

// ==================== SESSION ====================

export async function createSession(
  userId: string,
  ip?: string,
  userAgent?: string
): Promise<{ token: string; sessionId: string }> {
  const sessionId = uuidv4();
  const token = generateToken({
    userId,
    email: "",
    role: "user",
    sessionId,
  });

  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + 7);

  await db.insert(sessions).values({
    id: sessionId,
    userId,
    token,
    expiresAt,
    ip: ip || null,
    userAgent: userAgent || null,
  });

  return { token, sessionId };
}

export async function validateSession(token: string): Promise<JWTPayload | null> {
  const payload = verifyToken(token);
  if (!payload) return null;

  const session = await db
    .select()
    .from(sessions)
    .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date())))
    .limit(1);

  if (session.length === 0) return null;

  return payload;
}

export async function deleteSession(token: string): Promise<void> {
  await db.delete(sessions).where(eq(sessions.token, token));
}

export async function deleteAllUserSessions(userId: string, exceptToken?: string): Promise<void> {
  if (exceptToken) {
    await db.delete(sessions).where(
      and(eq(sessions.userId, userId), sql`${sessions.token} != ${exceptToken}`)
    );
  } else {
    await db.delete(sessions).where(eq(sessions.userId, userId));
  }
}

// ==================== LOGIN ATTEMPTS ====================

export async function recordLoginAttempt(email: string, ip: string, success: boolean): Promise<void> {
  await db.insert(loginAttempts).values({
    email,
    ip,
    success,
  });
}

export async function checkLoginAttempts(email: string): Promise<{ allowed: boolean; lockedUntil: Date | null }> {
  const fifteenMinutesAgo = new Date(Date.now() - 15 * 60 * 1000);

  const recentAttempts = await db
    .select()
    .from(loginAttempts)
    .where(
      and(
        eq(loginAttempts.email, email),
        eq(loginAttempts.success, false),
        gt(loginAttempts.createdAt, fifteenMinutesAgo)
      )
    );

  if (recentAttempts.length >= MAX_LOGIN_ATTEMPTS) {
    const lastAttempt = recentAttempts[recentAttempts.length - 1];
    const lockedUntil = new Date(
      lastAttempt.createdAt.getTime() + LOCK_DURATION_MINUTES * 60 * 1000
    );
    if (new Date() < lockedUntil) {
      return { allowed: false, lockedUntil };
    }
  }

  return { allowed: true, lockedUntil: null };
}

export async function incrementFailedAttempts(userId: string): Promise<void> {
  await db
    .update(users)
    .set({
      failedLoginAttempts: sql`${users.failedLoginAttempts} + 1`,
      lockedUntil:
        sql`CASE WHEN ${users.failedLoginAttempts} + 1 >= ${MAX_LOGIN_ATTEMPTS} THEN NOW() + INTERVAL '${LOCK_DURATION_MINUTES} minutes' ELSE ${users.lockedUntil} END`,
    })
    .where(eq(users.id, userId));
}

export async function resetFailedAttempts(userId: string): Promise<void> {
  await db
    .update(users)
    .set({
      failedLoginAttempts: 0,
      lockedUntil: null,
      lastLoginAt: new Date(),
    })
    .where(eq(users.id, userId));
}

// ==================== AUTH HELPER ====================

export async function getUserFromRequest(request: Request): Promise<{
  user: typeof users.$inferSelect | null;
  error?: string;
}> {
  const authHeader = request.headers.get("authorization");
  let token: string | null = null;

  if (authHeader?.startsWith("Bearer ")) {
    token = authHeader.substring(7);
  }

  if (!token) {
    const cookieHeader = request.headers.get("cookie");
    if (cookieHeader) {
      const cookies = Object.fromEntries(
        cookieHeader.split("; ").map((c) => {
          const [key, ...v] = c.split("=");
          return [key, v.join("=")];
        })
      );
      token = cookies["auth_token"] || null;
    }
  }

  if (!token) {
    return { user: null, error: "No token provided" };
  }

  const payload = await validateSession(token);
  if (!payload) {
    return { user: null, error: "Invalid or expired token" };
  }

  const user = await db
    .select()
    .from(users)
    .where(eq(users.id, payload.userId))
    .limit(1);

  if (user.length === 0) {
    return { user: null, error: "User not found" };
  }

  if (!user[0].isActive) {
    return { user: null, error: "Account is deactivated" };
  }

  if (!user[0].emailVerified) {
    return { user: null, error: "Email not verified" };
  }

  return { user: user[0] };
}

export async function getAdminFromRequest(request: Request): Promise<{
  user: typeof users.$inferSelect | null;
  error?: string;
}> {
  const result = await getUserFromRequest(request);
  if (result.error) return result;
  if (result.user?.role !== "admin") {
    return { user: null, error: "Admin access required" };
  }
  return result;
}
