import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("vi-VN", {
    style: "currency",
    currency: "VND",
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatDate(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat("vi-VN", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(d);
}

export function formatDateShort(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat("vi-VN", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(d);
}

export function formatTime(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat("vi-VN", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).format(d);
}

export function generateOrderCode(): string {
  const now = new Date();
  const dateStr = now.getFullYear().toString() +
    (now.getMonth() + 1).toString().padStart(2, "0") +
    now.getDate().toString().padStart(2, "0");
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `FF-${dateStr}-${random}`;
}

export function generateReceiveCode(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let code = "";
  for (let i = 0; i < 8; i++) {
    if (i === 4) code += "-";
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

export function getTimeRemaining(expiresAt: Date | string): {
  total: number;
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isExpired: boolean;
} {
  const expire = typeof expiresAt === "string" ? new Date(expiresAt) : expiresAt;
  const total = expire.getTime() - Date.now();

  if (total <= 0) {
    return { total: 0, days: 0, hours: 0, minutes: 0, seconds: 0, isExpired: true };
  }

  const seconds = Math.floor((total / 1000) % 60);
  const minutes = Math.floor((total / 1000 / 60) % 60);
  const hours = Math.floor((total / (1000 * 60 * 60)) % 24);
  const days = Math.floor(total / (1000 * 60 * 60 * 24));

  return { total, days, hours, minutes, seconds, isExpired: false };
}

export function getProgressPercentage(startedAt: Date, expiresAt: Date): number {
  const total = expiresAt.getTime() - startedAt.getTime();
  const elapsed = Date.now() - startedAt.getTime();
  if (total <= 0) return 100;
  return Math.min(100, Math.max(0, (elapsed / total) * 100));
}

export function truncate(str: string, length: number): string {
  if (str.length <= length) return str;
  return str.slice(0, length) + "...";
}

export function getInitials(name: string): string {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

export function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    available: "text-green-400",
    pending_payment: "text-yellow-400",
    rented: "text-red-400",
    maintenance: "text-orange-400",
    locked: "text-gray-400",
    active: "text-green-400",
    awaiting_confirmation: "text-yellow-400",
    completed: "text-blue-400",
    expired: "text-gray-400",
    cancelled: "text-red-400",
    confirmed: "text-green-400",
    rejected: "text-red-400",
    pending: "text-yellow-400",
    refunded: "text-purple-400",
  };
  return colors[status] || "text-gray-400";
}

export function getStatusBgColor(status: string): string {
  const colors: Record<string, string> = {
    available: "bg-green-400/10 border-green-400/20",
    pending_payment: "bg-yellow-400/10 border-yellow-400/20",
    rented: "bg-red-400/10 border-red-400/20",
    maintenance: "bg-orange-400/10 border-orange-400/20",
    locked: "bg-gray-400/10 border-gray-400/20",
    active: "bg-green-400/10 border-green-400/20",
    awaiting_confirmation: "bg-yellow-400/10 border-yellow-400/20",
    completed: "bg-blue-400/10 border-blue-400/20",
    expired: "bg-gray-400/10 border-gray-400/20",
    cancelled: "bg-red-400/10 border-red-400/20",
    confirmed: "bg-green-400/10 border-green-400/20",
    rejected: "bg-red-400/10 border-red-400/20",
    pending: "bg-yellow-400/10 border-yellow-400/20",
  };
  return colors[status] || "bg-gray-400/10 border-gray-400/20";
}

export function getStatusLabel(status: string): string {
  const labels: Record<string, string> = {
    available: "Có sẵn",
    pending_payment: "Chờ thanh toán",
    rented: "Đang thuê",
    maintenance: "Bảo trì",
    locked: "Tạm khóa",
    active: "Đang hoạt động",
    awaiting_confirmation: "Chờ xác nhận",
    completed: "Hoàn thành",
    expired: "Đã hết hạn",
    cancelled: "Đã hủy",
    confirmed: "Đã xác nhận",
    rejected: "Đã từ chối",
    pending: "Chờ xử lý",
    refunded: "Đã hoàn tiền",
  };
  return labels[status] || status;
}

export function getClientIp(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0].trim();
  const realIp = request.headers.get("x-real-ip");
  if (realIp) return realIp;
  return "unknown";
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, "")
    .replace(/[\s_-]+/g, "-")
    .replace(/^-+|-+$/g, "");
}
