export const APP_NAME = "FF Rent";
export const APP_DESCRIPTION = "Cho thuê tài khoản Free Fire theo giờ - Uy tín, Nhanh chóng, An toàn";
export const APP_URL = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";

export const SUPPORT_PHONE = "0818105658";
export const SUPPORT_EMAIL = "support@ffrent.vn";
export const SUPPORT_ZALO = "https://zalo.me/0818105658";

export const BANK_INFO = {
  bankName: "Vietcombank",
  accountNumber: "0123456789",
  accountName: "NGUYEN VAN A",
  branch: "Chi nhánh Hà Nội",
};

export const RENTAL_HOURS = [1, 2, 3, 4] as const;

export const HOLD_DURATION_MINUTES = 15;

export const PASSWORD_REQUIREMENTS = {
  minLength: 8,
  requireUppercase: true,
  requireLowercase: true,
  requireNumber: true,
  requireSpecial: false,
};

export const DEFAULT_ACCOUNTS = [
  {
    name: "Acc 1 - Diamond",
    description: "Tài khoản Diamond với nhiều skin hiếm, rank cao, đầy đủ nhân vật",
    level: "68",
    rank: "Heroic",
    pricing: [
      { hours: 1, price: 30000 },
      { hours: 2, price: 50000 },
      { hours: 3, price: 60000 },
      { hours: 4, price: 80000 },
    ],
  },
  {
    name: "Acc 2 - Elite",
    description: "Tài khoản Elite với skin đặc biệt, nhiều vũ khí legendary",
    level: "72",
    rank: "Grandmaster",
    pricing: [
      { hours: 1, price: 35000 },
      { hours: 2, price: 60000 },
      { hours: 3, price: 70000 },
      { hours: 4, price: 90000 },
    ],
  },
  {
    name: "Acc 3 - Premium",
    description: "Tài khoản Premium với bộ sưu tập skin giới hạn, đầy đủ nhân vật",
    level: "65",
    rank: "Heroic",
    pricing: [
      { hours: 1, price: 30000 },
      { hours: 2, price: 50000 },
      { hours: 3, price: 60000 },
      { hours: 4, price: 80000 },
    ],
  },
  {
    name: "Acc 4 - Standard",
    description: "Tài khoản Standard với nhiều nhân vật, vũ khí tốt, phù hợp người mới",
    level: "55",
    rank: "Diamond",
    pricing: [
      { hours: 1, price: 25000 },
      { hours: 2, price: 40000 },
      { hours: 3, price: 50000 },
      { hours: 4, price: 70000 },
    ],
  },
  {
    name: "Acc 5 - Classic",
    description: "Tài khoản Classic với nhiều skin seasonal, rank ổn định",
    level: "60",
    rank: "Heroic",
    pricing: [
      { hours: 1, price: 30000 },
      { hours: 2, price: 50000 },
      { hours: 3, price: 60000 },
      { hours: 4, price: 80000 },
    ],
  },
  {
    name: "Acc 6 - Starter",
    description: "Tài khoản Starter giá rẻ, phù hợp trải nghiệm, nhiều nhân vật cơ bản",
    level: "45",
    rank: "Gold",
    pricing: [
      { hours: 1, price: 20000 },
      { hours: 2, price: 40000 },
      { hours: 3, price: 50000 },
      { hours: 4, price: 60000 },
    ],
  },
];

export const NAV_LINKS = [
  { href: "/", label: "Trang chủ" },
  { href: "/accounts", label: "Tài khoản" },
  { href: "/pricing", label: "Bảng giá" },
  { href: "/orders", label: "Tra cứu" },
  { href: "/contact", label: "Liên hệ" },
];

export const FAQ_ITEMS = [
  {
    question: "Làm thế nào để thuê tài khoản?",
    answer: "Bạn cần đăng ký tài khoản, chọn tài khoản Free Fire muốn thuê, chọn số giờ thuê, sau đó chuyển khoản theo thông tin hướng dẫn. Sau khi Admin xác nhận thanh toán, bạn sẽ nhận được mã nhận tài khoản.",
  },
  {
    question: "Thời gian thuê tính như thế nào?",
    answer: "Thời gian thuê bắt đầu tính từ khi Admin xác nhận thanh toán. Ví dụ: Bạn thuê 2 giờ lúc 20:15, thời gian kết thúc sẽ là 22:15. Bạn có thể gia hạn thêm nếu muốn.",
  },
  {
    question: "Làm sao để nhận thông tin tài khoản?",
    answer: "Sau khi Admin xác nhận thanh toán, website sẽ cung cấp mã nhận tài khoản. Bạn gửi mã này qua Zalo hoặc số điện thoại hỗ trợ để nhận thông tin đăng nhập.",
  },
  {
    question: "Tôi có thể gia hạn thuê không?",
    answer: "Có! Khi đang thuê, bạn có thể bấm nút 'Gia hạn' để chọn thêm số giờ. Bạn cần thanh toán thêm cho thời gian gia hạn. Thời gian mới sẽ được cộng thêm vào thời gian hiện tại.",
  },
  {
    question: "Nếu tài khoản bị lỗi trong lúc thuê?",
    answer: "Vui lòng liên hệ ngay với Admin qua Zalo hoặc số điện thoại hỗ trợ. Chúng tôi sẽ xử lý nhanh chóng hoặc hoàn tiền nếu cần.",
  },
  {
    question: "Có được hoàn tiền không?",
    answer: "Nếu tài khoản gặp sự cố không thể sử dụng do lỗi từ phía chúng tôi, bạn sẽ được hoàn tiền toàn bộ. Vui lòng liên hệ Admin để xử lý.",
  },
];

export const TESTIMONIALS = [
  {
    name: "Minh Tuấn",
    content: "Dịch vụ thuê acc rất tốt, giá rẻ, acc xịn. Sẽ quay lại thuê tiếp!",
    rating: 5,
  },
  {
    name: "Thanh Hà",
    content: "Thuê acc nhanh chóng, Admin hỗ trợ nhiệt tình. Rất hài lòng!",
    rating: 5,
  },
  {
    name: "Hoàng Nam",
    content: "Acc nhiều skin đẹp, chơi rất mượt. Giá hợp lý cho sinh viên.",
    rating: 4,
  },
  {
    name: "Phương Linh",
    content: "Lần đầu thuê acc online mà rất uy tín. Sẽ giới thiệu cho bạn bè!",
    rating: 5,
  },
];
