import { z } from "zod";

// ==================== AUTH ====================

export const registerSchema = z.object({
  fullName: z
    .string()
    .min(2, "Họ tên phải có ít nhất 2 ký tự")
    .max(255, "Họ tên không được quá 255 ký tự"),
  username: z
    .string()
    .min(3, "Username phải có ít nhất 3 ký tự")
    .max(100, "Username không được quá 100 ký tự")
    .regex(/^[a-zA-Z0-9_]+$/, "Username chỉ được chứa chữ cái, số và dấu gạch dưới"),
  email: z.string().email("Email không hợp lệ"),
  phone: z
    .string()
    .regex(/^(0[3-9])[0-9]{8}$/, "Số điện thoại không hợp lệ"),
  password: z
    .string()
    .min(8, "Mật khẩu phải có ít nhất 8 ký tự")
    .regex(/[A-Z]/, "Mật khẩu phải có ít nhất 1 chữ hoa")
    .regex(/[a-z]/, "Mật khẩu phải có ít nhất 1 chữ thường")
    .regex(/[0-9]/, "Mật khẩu phải có ít nhất 1 số"),
  confirmPassword: z.string(),
  agreeTerms: z.literal(true, {
    message: "Bạn phải đồng ý với Điều khoản sử dụng",
  }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Mật khẩu xác nhận không khớp",
  path: ["confirmPassword"],
});

export const loginSchema = z.object({
  login: z.string().min(1, "Vui lòng nhập email hoặc username"),
  password: z.string().min(1, "Vui lòng nhập mật khẩu"),
  remember: z.boolean().optional(),
});

export const forgotPasswordSchema = z.object({
  email: z.string().email("Email không hợp lệ"),
});

export const resetPasswordSchema = z.object({
  token: z.string().min(1, "Token không hợp lệ"),
  password: z
    .string()
    .min(8, "Mật khẩu phải có ít nhất 8 ký tự")
    .regex(/[A-Z]/, "Mật khẩu phải có ít nhất 1 chữ hoa")
    .regex(/[a-z]/, "Mật khẩu phải có ít nhất 1 chữ thường")
    .regex(/[0-9]/, "Mật khẩu phải có ít nhất 1 số"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Mật khẩu xác nhận không khớp",
  path: ["confirmPassword"],
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, "Vui lòng nhập mật khẩu hiện tại"),
  newPassword: z
    .string()
    .min(8, "Mật khẩu phải có ít nhất 8 ký tự")
    .regex(/[A-Z]/, "Mật khẩu phải có ít nhất 1 chữ hoa")
    .regex(/[a-z]/, "Mật khẩu phải có ít nhất 1 chữ thường")
    .regex(/[0-9]/, "Mật khẩu phải có ít nhất 1 số"),
  confirmNewPassword: z.string(),
}).refine((data) => data.newPassword === data.confirmNewPassword, {
  message: "Mật khẩu xác nhận không khớp",
  path: ["confirmNewPassword"],
}).refine((data) => data.currentPassword !== data.newPassword, {
  message: "Mật khẩu mới không được trùng với mật khẩu cũ",
  path: ["newPassword"],
});

// ==================== PROFILE ====================

export const updateProfileSchema = z.object({
  fullName: z
    .string()
    .min(2, "Họ tên phải có ít nhất 2 ký tự")
    .max(255, "Họ tên không được quá 255 ký tự"),
  username: z
    .string()
    .min(3, "Username phải có ít nhất 3 ký tự")
    .max(100, "Username không được quá 100 ký tự")
    .regex(/^[a-zA-Z0-9_]+$/, "Username chỉ được chứa chữ cái, số và dấu gạch dưới"),
  phone: z
    .string()
    .regex(/^(0[3-9])[0-9]{8}$/, "Số điện thoại không hợp lệ"),
});

// ==================== ORDER ====================

export const createOrderSchema = z.object({
  accountId: z.string().uuid("ID tài khoản không hợp lệ"),
  hours: z.number().int().min(1).max(4, "Tối đa 4 giờ mỗi lần thuê"),
  isExtension: z.boolean().optional(),
  parentOrderId: z.string().uuid().optional(),
});

export const confirmPaymentSchema = z.object({
  orderId: z.string().uuid("ID đơn hàng không hợp lệ"),
});

// ==================== ADMIN ====================

export const adminConfirmOrderSchema = z.object({
  orderId: z.string().uuid("ID đơn hàng không hợp lệ"),
  action: z.enum(["confirm", "reject"]),
  reason: z.string().optional(),
});

export const adminUpdateAccountSchema = z.object({
  name: z.string().min(1, "Tên không được để trống").max(255).optional(),
  description: z.string().optional(),
  gameEmail: z.string().email().optional().or(z.literal("")),
  gamePassword: z.string().optional(),
  level: z.string().optional(),
  rank: z.string().optional(),
  status: z.enum(["available", "pending_payment", "rented", "maintenance", "locked"]).optional(),
  isActive: z.boolean().optional(),
});

export const adminUpdatePricingSchema = z.object({
  pricing: z.array(
    z.object({
      id: z.string().uuid().optional(),
      hours: z.number().int().min(1).max(4),
      price: z.number().int().min(1000, "Giá phải lớn hơn 1.000đ"),
      isActive: z.boolean().optional(),
    })
  ),
});

export const adminUpdateUserSchema = z.object({
  fullName: z.string().min(2).max(255).optional(),
  role: z.enum(["user", "admin"]).optional(),
  isActive: z.boolean().optional(),
  emailVerified: z.boolean().optional(),
});

// ==================== TYPES ====================

export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type ForgotPasswordInput = z.infer<typeof forgotPasswordSchema>;
export type ResetPasswordInput = z.infer<typeof resetPasswordSchema>;
export type ChangePasswordInput = z.infer<typeof changePasswordSchema>;
export type UpdateProfileInput = z.infer<typeof updateProfileSchema>;
export type CreateOrderInput = z.infer<typeof createOrderSchema>;
export type ConfirmPaymentInput = z.infer<typeof confirmPaymentSchema>;
export type AdminConfirmOrderInput = z.infer<typeof adminConfirmOrderSchema>;
export type AdminUpdateAccountInput = z.infer<typeof adminUpdateAccountSchema>;
export type AdminUpdatePricingInput = z.infer<typeof adminUpdatePricingSchema>;
export type AdminUpdateUserInput = z.infer<typeof adminUpdateUserSchema>;
