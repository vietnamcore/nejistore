import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || "smtp.gmail.com",
  port: Number(process.env.SMTP_PORT) || 587,
  secure: false,
  auth: {
    user: process.env.SMTP_USER || "",
    pass: process.env.SMTP_PASS || "",
  },
});

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
}

export async function sendEmail({ to, subject, html }: EmailOptions): Promise<boolean> {
  try {
    if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
      console.log(`[Email] Would send to ${to}: ${subject}`);
      return true;
    }

    await transporter.sendMail({
      from: `"FF Rent" <${process.env.SMTP_USER}>`,
      to,
      subject,
      html,
    });
    return true;
  } catch (error) {
    console.error("Email send error:", error);
    return false;
  }
}

export function emailVerificationTemplate(token: string, baseUrl: string): string {
  const link = `${baseUrl}/verify-email?token=${token}`;
  return `
    <div style="max-width: 600px; margin: 0 auto; font-family: 'Inter', sans-serif; padding: 20px;">
      <div style="background: linear-gradient(135deg, #0a0a0a, #1a2e1a); border-radius: 16px; padding: 40px; text-align: center;">
        <h1 style="color: #4ade80; margin: 0 0 20px; font-size: 28px;">🎮 FF Rent</h1>
        <h2 style="color: #ffffff; margin: 0 0 16px; font-size: 22px;">Xác thực Email</h2>
        <p style="color: #a3a3a3; margin: 0 0 30px; font-size: 16px;">
          Vui lòng bấm nút bên dưới để xác thực email của bạn. Liên kết có hiệu lực trong 24 giờ.
        </p>
        <a href="${link}" style="background: linear-gradient(135deg, #22c55e, #16a34a); color: white; padding: 14px 32px; border-radius: 10px; text-decoration: none; font-size: 16px; font-weight: 600; display: inline-block;">
          Xác thực Email
        </a>
        <p style="color: #737373; margin: 20px 0 0; font-size: 14px;">
          Nếu nút không hoạt động, hãy sao chép liên kết sau vào trình duyệt:<br>
          <a href="${link}" style="color: #4ade80; word-break: break-all;">${link}</a>
        </p>
      </div>
    </div>
  `;
}

export function passwordResetTemplate(token: string, baseUrl: string): string {
  const link = `${baseUrl}/reset-password?token=${token}`;
  return `
    <div style="max-width: 600px; margin: 0 auto; font-family: 'Inter', sans-serif; padding: 20px;">
      <div style="background: linear-gradient(135deg, #0a0a0a, #1a2e1a); border-radius: 16px; padding: 40px; text-align: center;">
        <h1 style="color: #4ade80; margin: 0 0 20px; font-size: 28px;">🎮 FF Rent</h1>
        <h2 style="color: #ffffff; margin: 0 0 16px; font-size: 22px;">Đặt lại mật khẩu</h2>
        <p style="color: #a3a3a3; margin: 0 0 30px; font-size: 16px;">
          Bạn đã yêu cầu đặt lại mật khẩu. Liên kết có hiệu lực trong 15 phút.
        </p>
        <a href="${link}" style="background: linear-gradient(135deg, #22c55e, #16a34a); color: white; padding: 14px 32px; border-radius: 10px; text-decoration: none; font-size: 16px; font-weight: 600; display: inline-block;">
          Đặt lại mật khẩu
        </a>
        <p style="color: #737373; margin: 20px 0 0; font-size: 14px;">
          Nếu bạn không yêu cầu, hãy bỏ qua email này.
        </p>
      </div>
    </div>
  `;
}

export function loginAlertTemplate(ip: string, userAgent: string): string {
  return `
    <div style="max-width: 600px; margin: 0 auto; font-family: 'Inter', sans-serif; padding: 20px;">
      <div style="background: linear-gradient(135deg, #0a0a0a, #1a2e1a); border-radius: 16px; padding: 40px; text-align: center;">
        <h1 style="color: #f59e0b; margin: 0 0 20px; font-size: 28px;">⚠️ Cảnh báo bảo mật</h1>
        <h2 style="color: #ffffff; margin: 0 0 16px; font-size: 22px;">Đăng nhập từ thiết bị mới</h2>
        <p style="color: #a3a3a3; margin: 0 0 20px; font-size: 16px;">
          Tài khoản của bạn vừa được đăng nhập từ một thiết bị mới.
        </p>
        <div style="background: rgba(255,255,255,0.05); border-radius: 10px; padding: 16px; text-align: left;">
          <p style="color: #a3a3a3; margin: 0 0 8px;">IP: <span style="color: #fff;">${ip}</span></p>
          <p style="color: #a3a3a3; margin: 0;">Thiết bị: <span style="color: #fff;">${userAgent}</span></p>
        </div>
        <p style="color: #737373; margin: 20px 0 0; font-size: 14px;">
          Nếu không phải bạn, hãy đổi mật khẩu ngay lập tức.
        </p>
      </div>
    </div>
  `;
}
