import "dotenv/config";
import { db } from "@/db";
import { users, ffAccounts, pricing, siteConfig } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { DEFAULT_ACCOUNTS } from "@/lib/constants";
import { eq } from "drizzle-orm";

async function seed() {
  console.log("🌱 Seeding database...");

  // Create admin user
  const existingAdmin = await db
    .select()
    .from(users)
    .where(eq(users.email, "admin@ffrent.vn"))
    .limit(1);

  if (existingAdmin.length === 0) {
    const hashedPassword = await hashPassword("Admin@123");
    await db.insert(users).values({
      email: "admin@ffrent.vn",
      username: "admin",
      fullName: "Quản trị viên",
      phone: "0818105658",
      password: hashedPassword,
      role: "admin",
      emailVerified: true,
      emailVerifiedAt: new Date(),
      isActive: true,
    });
    console.log("✅ Admin user created (admin@ffrent.vn / Admin@123)");
  } else {
    console.log("ℹ️ Admin user already exists");
  }

  // Create FF accounts with pricing
  for (let i = 0; i < DEFAULT_ACCOUNTS.length; i++) {
    const accData = DEFAULT_ACCOUNTS[i];

    const existing = await db
      .select()
      .from(ffAccounts)
      .where(eq(ffAccounts.name, accData.name))
      .limit(1);

    if (existing.length === 0) {
      const [account] = await db
        .insert(ffAccounts)
        .values({
          name: accData.name,
          description: accData.description,
          status: "available",
          level: accData.level,
          rank: accData.rank,
          gameEmail: `acc${i + 1}@freefire.com`,
          gamePassword: `GamePass${i + 1}@123`,
          isActive: true,
          sortOrder: i,
        })
        .returning();

      // Create pricing
      for (const p of accData.pricing) {
        await db.insert(pricing).values({
          accountId: account.id,
          hours: p.hours,
          price: p.price,
          isActive: true,
        });
      }
      console.log(`✅ Created ${accData.name}`);
    } else {
      console.log(`ℹ️ ${accData.name} already exists`);
    }
  }

  // Create site config
  const configs = [
    { key: "bank_name", value: "Vietcombank", description: "Tên ngân hàng" },
    { key: "bank_account_number", value: "0123456789", description: "Số tài khoản" },
    { key: "bank_account_name", value: "NGUYEN VAN A", description: "Tên chủ tài khoản" },
    { key: "support_phone", value: "0818105658", description: "Số điện thoại hỗ trợ" },
    { key: "support_email", value: "support@ffrent.vn", description: "Email hỗ trợ" },
    { key: "support_zalo", value: "https://zalo.me/0818105658", description: "Link Zalo" },
  ];

  for (const config of configs) {
    const existing = await db
      .select()
      .from(siteConfig)
      .where(eq(siteConfig.key, config.key))
      .limit(1);

    if (existing.length === 0) {
      await db.insert(siteConfig).values(config);
    }
  }
  console.log("✅ Site config created");

  console.log("🎉 Seeding complete!");
}

seed()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error("Seed error:", error);
    process.exit(1);
  });
