# FF Rental — Website cho thuê tài khoản Free Fire theo giờ

## Trạng thái: MODULE 1/N — Setup dự án & Database Schema ✅

### Đã hoàn thành trong module này

- Khởi tạo Next.js 15 (App Router) + TypeScript strict + Tailwind
- Cấu trúc thư mục Clean Architecture: `app/`, `src/components`, `src/features`,
  `src/layouts`, `src/hooks`, `src/services`, `src/lib`, `src/middleware`,
  `src/types`, `src/utils`, `src/constants`, `src/config`, `src/emails`
- **Prisma schema đầy đủ** (`prisma/schema.prisma`):
  - `User`, `Session`, `LoginHistory`, `EmailVerificationToken`,
    `PasswordResetToken`, `PasswordHistory`
  - `GameAccount`, `PriceTier`
  - `RentalOrder`, `Payment`
  - `Notification`
  - `AuditLog`
  - `SiteConfig`
- Design tokens (`tailwind.config.ts`, `globals.css`): xanh lá thiên nhiên +
  đen + glassmorphism, dark mode mặc định
- `prisma/seed.ts`: nạp sẵn 6 tài khoản Free Fire đúng bảng giá đã cung cấp
- `.env.example`, `next.config.js` (security headers), ESLint, Prettier

### Cách chạy (khi đã có PostgreSQL)

```bash
cp .env.example .env   # điền DATABASE_URL, AUTH_SECRET, v.v.
npm install
npx prisma migrate dev --name init
npm run db:seed
npm run dev
```

### Lộ trình các module tiếp theo (sẽ làm lần lượt, mỗi module xong 100% mới sang module sau)

1. ~~Setup dự án + Database Schema~~ ✅
2. Hệ thống Auth: đăng ký, xác thực email, đăng nhập, quên/đổi mật khẩu, session, rate-limit
3. Hồ sơ cá nhân + Dashboard người dùng
4. Danh sách & chi tiết tài khoản Free Fire (trang chủ, card, trạng thái)
5. Quy trình thuê: tạo đơn, giữ chỗ 15 phút, chống thuê trùng (transaction)
6. Thanh toán thủ công: hiển thị QR/STK, "Tôi đã thanh toán", mã nhận
7. Cron job: tự động hết hạn giữ chỗ, tự động hết hạn thuê, mở khóa acc
8. Gia hạn thuê
9. Tra cứu đơn, lịch sử thuê, lịch sử thanh toán, hóa đơn PDF
10. Trung tâm thông báo
11. Dashboard Admin: quản lý acc, xác nhận/từ chối thanh toán, đổi giá, audit log
12. SEO, PWA, Accessibility, tối ưu hiệu năng, hoàn thiện UI/animation

**Gõ "tiếp tục" để tôi làm Module 2 (Hệ thống Auth).**
