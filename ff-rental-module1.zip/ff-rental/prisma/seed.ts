import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

// hours -> price VND, per account, exactly as specified in the business requirements
const ACCOUNTS: {
  name: string
  slug: string
  gameEmail: string
  prices: { hours: number; priceVnd: number }[]
}[] = [
  {
    name: 'Acc 1',
    slug: 'acc-1',
    gameEmail: 'placeholder-acc1@example.com',
    prices: [
      { hours: 1, priceVnd: 30000 },
      { hours: 2, priceVnd: 50000 },
      { hours: 3, priceVnd: 60000 },
      { hours: 4, priceVnd: 80000 },
    ],
  },
  {
    name: 'Acc 2',
    slug: 'acc-2',
    gameEmail: 'placeholder-acc2@example.com',
    prices: [
      { hours: 1, priceVnd: 35000 },
      { hours: 2, priceVnd: 60000 },
      { hours: 3, priceVnd: 70000 },
      { hours: 4, priceVnd: 90000 },
    ],
  },
  {
    name: 'Acc 3',
    slug: 'acc-3',
    gameEmail: 'placeholder-acc3@example.com',
    prices: [
      { hours: 1, priceVnd: 30000 },
      { hours: 2, priceVnd: 50000 },
      { hours: 3, priceVnd: 60000 },
      { hours: 4, priceVnd: 80000 },
    ],
  },
  {
    name: 'Acc 4',
    slug: 'acc-4',
    gameEmail: 'placeholder-acc4@example.com',
    prices: [
      { hours: 1, priceVnd: 25000 },
      { hours: 2, priceVnd: 40000 },
      { hours: 3, priceVnd: 50000 },
      { hours: 4, priceVnd: 70000 },
    ],
  },
  {
    name: 'Acc 5',
    slug: 'acc-5',
    gameEmail: 'placeholder-acc5@example.com',
    prices: [
      { hours: 1, priceVnd: 30000 },
      { hours: 2, priceVnd: 50000 },
      { hours: 3, priceVnd: 60000 },
      { hours: 4, priceVnd: 80000 },
    ],
  },
  {
    name: 'Acc 6',
    slug: 'acc-6',
    gameEmail: 'placeholder-acc6@example.com',
    prices: [
      { hours: 1, priceVnd: 20000 },
      { hours: 2, priceVnd: 40000 },
      { hours: 3, priceVnd: 50000 },
      { hours: 4, priceVnd: 60000 },
    ],
  },
]

async function main() {
  // --- Site config (singleton row) ---
  await prisma.siteConfig.upsert({
    where: { id: 'singleton' },
    update: {},
    create: {
      id: 'singleton',
      siteName: 'FF Rental',
      supportPhone: '0818105658',
      bankName: 'Thay bằng tên ngân hàng thật',
      bankAccountName: 'Thay bằng tên chủ tài khoản thật',
      bankAccountNo: 'Thay bằng số tài khoản thật',
      holdDurationMin: 15,
    },
  })

  // --- Admin account (change password immediately after first login) ---
  const adminPasswordHash = await bcrypt.hash('ChangeMeImmediately123!', 12)
  await prisma.user.upsert({
    where: { email: 'admin@ffrental.local' },
    update: {},
    create: {
      fullName: 'Quản trị viên',
      username: 'admin',
      email: 'admin@ffrental.local',
      phone: '0000000000',
      passwordHash: adminPasswordHash,
      role: 'ADMIN',
      status: 'ACTIVE',
      emailVerified: true,
      emailVerifiedAt: new Date(),
    },
  })

  // --- Game accounts + price tiers ---
  // NOTE: gamePasswordEnc must be set via the Admin Dashboard (encrypted with
  // CREDENTIALS_ENCRYPTION_KEY), never committed to seed data in plaintext.
  for (const acc of ACCOUNTS) {
    const created = await prisma.gameAccount.upsert({
      where: { slug: acc.slug },
      update: {},
      create: {
        name: acc.name,
        slug: acc.slug,
        thumbnailUrl: `/images/accounts/${acc.slug}.jpg`,
        gameEmail: acc.gameEmail,
        gamePasswordEnc: 'SET_VIA_ADMIN_DASHBOARD',
        status: 'AVAILABLE',
      },
    })

    for (const tier of acc.prices) {
      await prisma.priceTier.upsert({
        where: { gameAccountId_hours: { gameAccountId: created.id, hours: tier.hours } },
        update: { priceVnd: tier.priceVnd },
        create: {
          gameAccountId: created.id,
          hours: tier.hours,
          priceVnd: tier.priceVnd,
        },
      })
    }
  }

  console.log('Seed completed: 1 admin, 6 game accounts, 24 price tiers, site config.')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
